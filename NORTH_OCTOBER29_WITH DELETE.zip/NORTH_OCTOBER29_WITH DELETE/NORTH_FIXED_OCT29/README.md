# 🧭 North — Stay on course

North is a student productivity dashboard with a dark charcoal and purple-blue interface inspired by the OBSIDIAN login design. It keeps the North name and compass identity.

## Run locally

1. Extract the project folder.
2. Open `login.html` in a browser, or use VS Code with the Live Server extension.
3. Create a demo account, then sign in. The dashboard is `index.html`.

## Features

- Responsive desktop and mobile layout with a mobile navigation drawer
- North branding, dark cards, subtle cursor-following ambient glow on mouse devices
- Live local clock and greeting
- Live weather for the Lipa City area through Open-Meteo (requires internet)
- Add, check off, and delete tasks; automatic progress tracker
- Add and delete schedule entries
- Auto-saved quick notes
- 25-minute focus timer with pause and reset
- Demo sign-up/sign-in flow and sign-out

## Important security note

Authentication is only a front-end demonstration. Demo account data is stored in browser `localStorage`; the password is SHA-256 hashed where Web Crypto is available, but this is **not** a substitute for secure authentication. Do not use real or reused passwords. For production, connect a backend with a proper password-hashing algorithm, secure sessions, validation, and account recovery.

Built with HTML, CSS, and vanilla JavaScript. No build step is required.

## Google Weather + Google Calendar setup

North can show the current date/time automatically, use browser-approved device location for live Google Weather conditions, and display upcoming events from a Google Calendar account. No new login/signup page was added; Calendar authorization is a separate Google consent prompt and only requests read-only event access.

### 1. Configure credentials

Open `js/config.js` and replace the placeholders:

- `googleWeatherApiKey`: a Google Maps Platform API key with **Weather API** enabled.
- `googleCalendarClientId`: an OAuth 2.0 Client ID for a **Web application**.
- `googleCalendarApiKey`: an API key with **Google Calendar API** enabled. It may be the same key as the Weather key only if the key's API restrictions permit both APIs.

Google Cloud setup:

1. Create/select a project in Google Cloud Console.
2. Enable **Weather API** and **Google Calendar API**.
3. Create an API key. Restrict it to the APIs you use and add website HTTP-referrer restrictions for your deployed site. API keys used in browser code are visible to users, so referrer/API restrictions are important.
4. Configure Google Auth Platform / OAuth consent screen.
5. Create an OAuth client with application type **Web application**. Add your local development origin (for example `http://localhost:8000`) and your deployed site's origin under **Authorized JavaScript origins**.
6. Copy the OAuth Client ID into `js/config.js`. Do not put a client secret in this front-end project.
7. For an external/testing consent screen, add your Google account as a test user if required by the consent-screen configuration.

### 2. Run the dashboard

From this folder, run `python3 -m http.server 8000` (or `npm start` if Python is available), then open `http://localhost:8000`. Use localhost or HTTPS; browser geolocation is not normally available on an insecure remote HTTP site. Allow location access when prompted. The weather refreshes about every 30 minutes; Google Calendar events refresh about every 5 minutes while connected.

### Notes

- Date and time use the browser/device clock and time zone; they do not require Google.
- Weather is fetched from Google's Weather API based on coordinates provided by the browser after permission is granted. If permission is denied, enable it in browser site settings and reload.
- Google Calendar only requests `calendar.events.readonly`; the user must explicitly press **Connect Google** and consent.
- Weather API production use may require billing. Google documents a no-cost demo key for prototyping, not production.
- The dashboard is a static front-end project. For a public multi-user deployment, consider a backend or a more formal OAuth/session design and review Google's current API policies.


## Dedicated Calendar page
The Calendar navigation item opens `calendar.html` as a separate full-page view. Configure `googleCalendarClientId` and `googleCalendarApiKey` in `js/config.js`, enable Google Calendar API, and authorize the account to load private upcoming events. A private calendar may not be available through the default iframe embed; use the Google authorization panel or set `googleCalendarEmbedUrl` to an embed URL copied from Google Calendar settings.


## Google Calendar editing in North

The standalone `calendar.html` page uses the Google Calendar API to list, create, update, and delete events on the configured calendar. Configure a Google Cloud **Web application** OAuth client and API key in `js/config.js`; enable the Google Calendar API; add the exact origin used by your local server (for example `http://localhost:8000`) under Authorized JavaScript origins; and add your account as a test user if the OAuth app is in testing mode. The app requests `https://www.googleapis.com/auth/calendar.events` so event edits are saved to Google. After changing from read-only permissions, disconnect/revoke the old authorization and connect again to approve the new scope. Restrict the browser API key to the Calendar API and your site origins.

Run locally from the project folder with `py -m http.server 8000`, then open `http://localhost:8000`. Do not open the HTML file directly from disk.
