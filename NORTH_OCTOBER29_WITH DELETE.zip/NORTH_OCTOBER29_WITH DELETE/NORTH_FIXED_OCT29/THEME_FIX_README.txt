NORTH THEME FIX

Files included:
- tasks.html
- focus.html
- statistics.html

Apply this patch by extracting the ZIP into your North project root folder, preserving the folders/filenames, and replacing only the three listed HTML files.

The Tasks and Focus pages now include a visible sun/moon theme button in the profile row. They read and write the same localStorage key used by North Settings: north-theme. Their light theme uses the warm beige palette.

The Statistics page has additional high-contrast light-mode styles for its custom statistics cards, numbers, captions, weekly bars, and recent-session rows.

After copying the files, deploy from the project root:
  firebase deploy --only hosting

Then hard-refresh the site with Ctrl+Shift+R. Test the theme switch on Tasks and Focus, and check that switching pages retains the selected theme.
