NORTH ACCOUNT DELETION RESTORE

This package is based on the previous North sign-out-format version and restores the Delete Account area to Settings. It adds js/delete-account.js, the matching danger-zone styles, and Firestore rules that permit a signed-in user to read/delete only their own user_logins records.

Install by extracting into Downloads so the included NORTH_FIXED_OCT29 folder merges into your existing folder. Then from the inner project folder run:

  firebase deploy --only hosting,firestore:rules

Deletion requires the user to reauthenticate. Email/password accounts must enter their current password; Google accounts must complete the Google popup. This uses client-side deletion because Firebase Cloud Functions deployment requires the Blaze plan. Test carefully before using on real data.
