# NORTH project fixes

This ZIP contains the cleaned root NORTH project, with the duplicate nested project snapshot and the bundled `firebase.exe` omitted. The executable is not needed by the website at runtime.

## Changes made

- Removed the duplicate Firebase Authentication import in `js/app.js`, which caused a syntax error and prevented the dashboard/settings/statistics script from loading.
- Corrected `tasks.html` so `signOut` is imported from the Firebase Authentication SDK rather than from `js/firebase.js` (which does not export it).
- Updated Calendar to use Firebase Auth and Firestore for North-only plans under `users/{uid}.calendarPlans`, with real-time updates, account-scoped local cache, and a confirmation before importing plans from the old shared local-storage key.
- Scoped saved Google Calendar tokens and Google account display cache to the signed-in Firebase UID to avoid reusing them across North accounts.
- Added a sign-out button to Calendar.
- Repaired `statistics.html`, which had been using Settings page styling/content, and added Firestore-driven task, focus-session, focus-time, calendar-plan, weekly-focus, and recent-session statistics.
- Added `firestore.rules` and connected it in `firebase.json`. Rules permit a signed-in user to access only their own `users/{uid}` document and permit creation of that user's login log entries.
- Preserved the existing UI styles and Firebase project configuration.

## Before deploying

1. Run the site over localhost or Firebase Hosting; do not open the HTML files directly with `file://`.
2. Review `firestore.rules` against your current production rules before deploying. These rules are configured for this project's current client code and deny access to any other collections.
3. To deploy Hosting and these Firestore rules together, use `firebase deploy --only hosting,firestore:rules` from this project folder after signing in to the Firebase CLI.
4. Restrict the Google Calendar API key to your deployed site's HTTP referrers and the Calendar API in Google Cloud Console. Confirm the OAuth client has the correct authorized JavaScript origins.
5. Test login, logout, task creation/completion, focus-session saving, Calendar plan create/edit/delete, Google Calendar connect/disconnect, and account settings with a test account before relying on production data.

## Validation performed

- JavaScript syntax checks passed for all standalone JS files and inline module scripts.
- `firebase.json` parses as valid JSON.
- Local HTML/CSS/JS references were checked; no missing local references were found.

Live Firebase authentication, Firestore permissions, Google OAuth, and Calendar API behavior depend on the deployed Firebase/Google Cloud settings and must be verified in the actual environment.
