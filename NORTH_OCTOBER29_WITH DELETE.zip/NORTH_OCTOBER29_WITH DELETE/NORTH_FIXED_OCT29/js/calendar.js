import { auth, db, onAuthStateChanged, doc, setDoc, onSnapshot, serverTimestamp } from "./firebase.js";
import { signOut } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

(() => {
    const $ = (id) => document.getElementById(id);
    const cfg = () => window.NORTH_CONFIG || {};
    function paintNorthAccount() {
        let user = null;
        try {
            user = JSON.parse(
                sessionStorage.getItem("north-user") || localStorage.getItem("north-remember-user") || "null"
            );
        } catch {}
        const name = $("north-account-name"),
            email = $("north-account-email"),
            avatar = $("north-account-avatar");
        if (!name || !email || !avatar) return;
        if (user) {
            name.textContent = user.name || "North";
            email.textContent = user.email || "";
            const picture = localStorage.getItem("north-profile-picture");
            if (picture) {
                avatar.textContent = "";
                avatar.style.backgroundImage = "url(" + JSON.stringify(picture) + ")";
                avatar.classList.add("avatar-with-image");
            } else {
                avatar.style.backgroundImage = "";
                avatar.classList.remove("avatar-with-image");
                avatar.textContent = (user.name || "N").trim().charAt(0).toUpperCase();
            }
        } else {
            name.textContent = "North";
            email.textContent = "Sign in to North";
            avatar.style.backgroundImage = "";
            avatar.classList.remove("avatar-with-image");
            avatar.textContent = "N";
        }
    }
    paintNorthAccount();
    const discovery = "https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest";
    const scope = "openid email profile https://www.googleapis.com/auth/calendar.events";
    const TOKEN_KEY = "north-google-calendar-token";
    const ACCOUNT_KEY = "north-google-calendar-account";
    const tokenStorageKey = () => `${TOKEN_KEY}-${currentUser?.uid || "guest"}`;
    const accountStorageKey = () => `${ACCOUNT_KEY}-${currentUser?.uid || "guest"}`;
    let currentUser = null;
    let localPlans = [];
    let plansUnsubscribe = null;
    let plansReady = false;
    let plansWriteQueue = Promise.resolve();
    let apiReady = false,
        identityReady = false,
        tokenClient = null,
        token = null,
        events = [],
        googleEvents = [],
        editingId = null,
        editingLocal = false;
    const LOCAL_KEY = "north-local-plans-v1";
    const expandedDays = new Set();
    let viewDate = new Date();
    viewDate.setDate(1);
    const configured = () =>
        !!(
            cfg().googleCalendarClientId &&
            cfg().googleCalendarApiKey &&
            !/YOUR_|PASTE_/.test(cfg().googleCalendarClientId + cfg().googleCalendarApiKey)
        );
    function status(s) {
        $("events-status").textContent = s;
    }
    function readAccount() {
        try {
            return JSON.parse(localStorage.getItem(accountStorageKey()) || "null");
        } catch {
            return null;
        }
    }
    function paintAccount(account) {
        const name = $("google-account-name"),
            email = $("google-account-email"),
            avatar = $("google-account-avatar");
        if (!name || !email || !avatar) return;
        if (account && account.email) {
            name.textContent = account.name || account.email;
            email.textContent = account.email;
            avatar.textContent = (account.name || account.email).trim().charAt(0).toUpperCase();
        } else {
            name.textContent = "Google Calendar";
            email.textContent = "Connect your account";
            avatar.textContent = "G";
        }
    }
    async function saveAccountFromToken(accessToken) {
        try {
            const response = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
                headers: { Authorization: "Bearer " + accessToken }
            });
            if (!response.ok) throw new Error("Could not read Google profile");
            const profile = await response.json();
            const account = {
                name: profile.name || profile.email,
                email: profile.email,
                picture: profile.picture || ""
            };
            localStorage.setItem(accountStorageKey(), JSON.stringify(account));
            paintAccount(account);
        } catch (e) {
            console.warn("Google account profile could not be loaded", e);
            paintAccount(readAccount());
        }
    }
    function restoreSavedToken() {
        try {
            const saved = JSON.parse(localStorage.getItem(tokenStorageKey()) || "null");
            if (saved?.access_token && saved.expires_at > Date.now()) {
                token = saved.access_token;
                if (window.gapi?.client) gapi.client.setToken({ access_token: token });
                setConnected(true);
                status("Restoring Google Calendar connection…");
                loadEvents();
            } else {
                localStorage.removeItem(tokenStorageKey());
            }
        } catch (e) {
            console.warn(e);
        }
    }
    window.addEventListener("storage", (e) => {
        if (e.key === tokenStorageKey()) {
            restoreSavedToken();
            if (!localStorage.getItem(tokenStorageKey())) {
                token = null;
                events = [];
                if (window.gapi?.client) gapi.client.setToken("");
                setConnected(false);
                render();
                status("Google Calendar is not connected.");
            }
        }
    });
    function localDate(d) {
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    }
    function fmtDate(date, time) {
        if (!time) return date;
        return new Date(`${date}T${time}`).toLocaleString([], {
            month: "short",
            day: "numeric",
            hour: "numeric",
            minute: "2-digit"
        });
    }
    function eventStart(e) {
        return e.start?.dateTime
            ? new Date(e.start.dateTime)
            : new Date(`${e.start?.date || localDate(new Date())}T00:00:00`);
    }
    function eventEnd(e) {
        return e.end?.dateTime
            ? new Date(e.end.dateTime)
            : new Date(`${e.end?.date || e.start?.date || localDate(new Date())}T00:00:00`);
    }
    function eventDateKey(e) {
        return e.start?.dateTime ? localDate(eventStart(e)) : e.start?.date || "";
    }
    function readLocalPlans() {
        return Array.isArray(localPlans) ? localPlans : [];
    }
    function writeLocalPlans(plans) {
        if (!currentUser || !plansReady) {
            throw new Error("Please wait for your North account to finish loading before saving a plan.");
        }
        localPlans = Array.isArray(plans) ? plans : [];
        localStorage.setItem(`${LOCAL_KEY}-${currentUser.uid}`, JSON.stringify(localPlans));
        combineEvents();
        render();
        const userRef = doc(db, "users", currentUser.uid);
        const plansToSave = localPlans.map((plan) => ({ ...plan }));
        plansWriteQueue = plansWriteQueue.catch(() => {}).then(() =>
            setDoc(userRef, { calendarPlans: plansToSave, updatedAt: serverTimestamp() }, { merge: true })
        );
        return plansWriteQueue;
    }
    function categoryOf(e) {
        const c = String(e.northCategory || "other").toLowerCase();
        return ["personal", "study", "work", "health", "other"].includes(c) ? c : "other";
    }
    function combineEvents() {
        events = [...googleEvents, ...readLocalPlans()];
    }
    function render() {
        const grid = $("calendar-grid");
        grid.innerHTML = "";
        $("month-label").textContent = viewDate.toLocaleDateString([], { month: "long", year: "numeric" });
        ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].forEach((d) => {
            const n = document.createElement("div");
            n.className = "weekday";
            n.textContent = d;
            grid.append(n);
        });
        const first = new Date(viewDate.getFullYear(), viewDate.getMonth(), 1);
        const start = new Date(first);
        start.setDate(first.getDate() - first.getDay());
        const today = localDate(new Date());
        for (let i = 0; i < 42; i++) {
            const day = new Date(start);
            day.setDate(start.getDate() + i);
            const key = localDate(day),
                cell = document.createElement("div");
            cell.className =
                "day-cell" +
                (day.getMonth() !== viewDate.getMonth() ? " outside" : "") +
                (key === today ? " today" : "") +
                (expandedDays.has(key) ? " expanded" : "");
            cell.dataset.date = key;
            const number = document.createElement("div");
            number.className = "day-number";
            number.textContent = day.getDate();
            cell.append(number);
            const dayEvents = events
                .filter((e) => eventDateKey(e) === key)
                .sort((a, b) => eventStart(a) - eventStart(b));
            const isExpanded = expandedDays.has(key);
            (isExpanded ? dayEvents : dayEvents.slice(0, 3)).forEach((e) => {
                const b = document.createElement("button");
                b.type = "button";
                b.className =
                    "day-event category-" +
                    categoryOf(e) +
                    (e.start?.date ? " all-day" : "") +
                    (e.northLocal ? " local-plan" : "");
                b.textContent = e.summary || "(Untitled event)";
                b.title = "Edit " + b.textContent;
                b.addEventListener("click", (ev) => {
                    ev.stopPropagation();
                    openEdit(e);
                });
                cell.append(b);
            });
            if (dayEvents.length > 3) {
                const more = document.createElement("button");
                more.type = "button";
                more.className = "more-events";
                more.textContent = isExpanded ? "Show less" : `+${dayEvents.length - 3} more`;
                more.addEventListener("click", (ev) => {
                    ev.preventDefault();
                    ev.stopPropagation();
                    if (isExpanded) expandedDays.delete(key);
                    else expandedDays.add(key);
                    render();
                });
                cell.append(more);
            }
            cell.addEventListener("click", () => openNew(key));
            grid.append(cell);
        }
        renderList();
    }
    function renderList() {
        const host = $("calendar-events");
        host.innerHTML = "";
        const now = new Date();
        const upcoming = events
            .filter((e) => eventEnd(e) >= new Date(now.getFullYear(), now.getMonth(), now.getDate()))
            .sort((a, b) => eventStart(a) - eventStart(b))
            .slice(0, 12);
        if (!upcoming.length) {
            host.innerHTML = '<p class="empty-events">No upcoming events. Create one with “New event”.</p>';
            return;
        }
        upcoming.forEach((e) => {
            const item = document.createElement("div");
            item.className = "event-item category-" + categoryOf(e);
            const main = document.createElement("div");
            main.className = "event-item-main";
            const title = document.createElement("strong");
            title.textContent = e.summary || "(Untitled event)";
            const detail = document.createElement("small");
            detail.textContent = e.start?.dateTime
                ? eventStart(e).toLocaleString([], {
                      weekday: "short",
                      month: "short",
                      day: "numeric",
                      hour: "numeric",
                      minute: "2-digit"
                  })
                : eventStart(e).toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" }) +
                  " · All day";
            if (e.location) detail.textContent += " · " + e.location;
            const source = document.createElement("small");
            source.className = "event-source-badge";
            source.textContent = e.northLocal ? "Saved in North · cloud synced" : "Google Calendar";
            main.append(title, detail, source);
            const edit = document.createElement("button");
            edit.className = "event-edit";
            edit.type = "button";
            edit.textContent = "Edit";
            edit.addEventListener("click", () => openEdit(e));
            item.append(main, edit);
            host.append(item);
        });
    }
    function guessCategory(e) {
        const s = ((e.summary || "") + " " + (e.description || "")).toLowerCase();
        if (/study|class|exam|quiz|assignment|school|review|lecture|homework/.test(s)) return "study";
        if (/work|meeting|project|office|deadline/.test(s)) return "work";
        if (/gym|doctor|health|exercise|workout/.test(s)) return "health";
        if (/personal|family|birthday|friend|hangout|errand/.test(s)) return "personal";
        return "other";
    }
    async function loadEvents() {
        if (!token || !apiReady) return;
        try {
            status("Syncing Google Calendar…");
            const r = await gapi.client.calendar.events.list({
                calendarId: cfg().googleCalendarId || "primary",
                timeMin: new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1).toISOString(),
                timeMax: new Date(new Date().getFullYear(), new Date().getMonth() + 4, 1).toISOString(),
                singleEvents: true,
                orderBy: "startTime",
                maxResults: 250,
                showDeleted: false
            });
            googleEvents = (r.result.items || []).map((e) => ({
                ...e,
                northCategory: e.extendedProperties?.private?.northCategory || e.northCategory || guessCategory(e)
            }));
            combineEvents();
            render();
            status("Connected · Google events sync and North plans sync to your account.");
        } catch (e) {
            console.error(e);
            status("Could not load events. Check API access and OAuth settings.");
        }
    }
    function setConnected(connected) {
        $("connect-google").hidden = connected;
        $("disconnect-google").hidden = !connected;
    }
    window.northCalendarGapiLoaded = () => {
        if (!window.gapi) return;
        gapi.load("client", async () => {
            try {
                if (!cfg().googleCalendarApiKey) return;
                await gapi.client.init({ apiKey: cfg().googleCalendarApiKey, discoveryDocs: [discovery] });
                apiReady = true;
                if (token) {
                    gapi.client.setToken({ access_token: token });
                    loadEvents();
                } else if (configured()) status("Ready to connect Google Calendar.");
            } catch (e) {
                console.error(e);
                status("Google Calendar API setup needs attention.");
            }
        });
    };
    window.northCalendarGisLoaded = () => {
        if (!window.google?.accounts?.oauth2) return;
        identityReady = true;
        if (!configured()) {
            status("Add your Google Calendar Client ID and API key in js/config.js.");
            return;
        }
        tokenClient = google.accounts.oauth2.initTokenClient({
            client_id: cfg().googleCalendarClientId,
            scope,
            callback: async (r) => {
                if (r.error) {
                    status("Google authorization was not completed.");
                    return;
                }
                token = r.access_token;
                localStorage.setItem(
                    tokenStorageKey(),
                    JSON.stringify({
                        access_token: token,
                        expires_at: Date.now() + (Number(r.expires_in) || 3600) * 1000 - 60000
                    })
                );
                gapi.client.setToken({ access_token: token });
                setConnected(true);
                await saveAccountFromToken(token);
                await loadEvents();
            }
        });
        status("Ready to connect Google Calendar.");
        paintAccount(readAccount());
        restoreSavedToken();
    };
    $("connect-google").addEventListener("click", () => {
        if (!configured()) {
            status("Add Google credentials in js/config.js first.");
            return;
        }
        if (!apiReady || !identityReady || !tokenClient) {
            status("Google services are loading. Try again shortly.");
            return;
        }
        tokenClient.requestAccessToken({ prompt: token ? "" : "select_account" });
    });
    $("disconnect-google").addEventListener("click", async () => {
        if (
            !(await window.northConfirm("North will stop syncing this Google Calendar until you connect again.", {
                title: "Disconnect Google Calendar?",
                confirmText: "Disconnect",
                danger: true
            }))
        )
            return;
        if (token && window.google?.accounts?.oauth2) google.accounts.oauth2.revoke(token, () => {});
        token = null;
        localStorage.removeItem(tokenStorageKey());
        if (window.gapi?.client) gapi.client.setToken("");
        googleEvents = [];
        combineEvents();
        render();
        setConnected(false);
        localStorage.removeItem(accountStorageKey());
        paintAccount(null);
        status("Disconnected from Google Calendar.");
    });
    function toggleAllDay() {
        const all = $("event-all-day").checked;
        $("event-start-time").disabled = all;
        $("event-end-time").disabled = all;
        if (all) {
            $("event-start-time").value = "09:00";
            $("event-end-time").value = "10:00";
        }
    }
    $("event-all-day").addEventListener("change", toggleAllDay);
    function openNew(date = localDate(new Date())) {
        editingId = null;
        editingLocal = false;
        $("event-form").reset();
        $("modal-title").textContent = "New plan";
        $("delete-event").hidden = true;
        $("event-start-date").value = date;
        $("event-end-date").value = date;
        $("event-start-time").value = "09:00";
        $("event-end-time").value = "10:00";
        $("event-category").value = "personal";
        $("event-source").value = "local";
        $("event-source").disabled = !token;
        $("form-error").textContent = "";
        toggleAllDay();
        $("event-modal").showModal();
        $("event-title").focus();
    }
    function openEdit(e) {
        editingId = e.id;
        editingLocal = !!e.northLocal;
        $("event-form").reset();
        $("modal-title").textContent = "Edit plan";
        $("delete-event").hidden = false;
        $("event-title").value = e.summary || "";
        $("event-location").value = e.location || "";
        $("event-description").value = e.description || "";
        $("event-category").value = categoryOf(e);
        $("event-source").value = editingLocal ? "local" : "google";
        $("event-source").disabled = !token;
        $("event-start-date").value = e.start?.date || localDate(eventStart(e));
        $("event-end-date").value = e.end?.date
            ? new Date(e.end.date + "T12:00:00") > new Date(e.start.date + "T12:00:00")
                ? new Date(new Date(e.end.date + "T12:00:00").getTime() - 86400000).toISOString().slice(0, 10)
                : e.end.date
            : localDate(eventEnd(e));
        $("event-start-time").value = e.start?.dateTime ? eventStart(e).toTimeString().slice(0, 5) : "09:00";
        $("event-end-time").value = e.end?.dateTime ? eventEnd(e).toTimeString().slice(0, 5) : "10:00";
        $("event-all-day").checked = !!e.start?.date;
        toggleAllDay();
        $("form-error").textContent = "";
        $("event-modal").showModal();
    }
    $("add-event").addEventListener("click", () => openNew());
    $("cancel-event").addEventListener("click", () => $("event-modal").close());
    $("prev-month").addEventListener("click", () => {
        viewDate.setMonth(viewDate.getMonth() - 1);
        render();
    });
    $("next-month").addEventListener("click", () => {
        viewDate.setMonth(viewDate.getMonth() + 1);
        render();
    });
    $("today-btn").addEventListener("click", () => {
        viewDate = new Date();
        viewDate.setDate(1);
        render();
    });
    function eventPayload() {
        const title = $("event-title").value.trim(),
            sd = $("event-start-date").value,
            ed = $("event-end-date").value,
            all = $("event-all-day").checked,
            st = $("event-start-time").value,
            et = $("event-end-time").value;
        if (!title) throw Error("Please enter an event title.");
        if (!sd || !ed || ed < sd) throw Error("End date must be on or after the start date.");
        const body = {
            summary: title,
            location: $("event-location").value.trim(),
            description: $("event-description").value.trim(),
            northCategory: $("event-category").value
        };
        if (all) {
            const end = new Date(ed + "T12:00:00");
            end.setDate(end.getDate() + 1);
            body.start = { date: sd };
            body.end = { date: localDate(end) };
        } else {
            if (!st || !et) throw Error("Please enter start and end times.");
            const start = new Date(`${sd}T${st}:00`),
                end = new Date(`${ed}T${et}:00`);
            if (end <= start) throw Error("End date and time must be after the start.");
            body.start = { dateTime: start.toISOString() };
            body.end = { dateTime: end.toISOString() };
        }
        return body;
    }
    $("event-form").addEventListener("submit", async (ev) => {
    ev.preventDefault();

    const btn = $("save-event");
    btn.disabled = true;
    btn.textContent = "Saving…";
    $("form-error").textContent = "";

    try {
        const body = eventPayload();
        const source = $("event-source").value;

        // Warn before saving a plan with a past start date.
        const todayKey = localDate(new Date());
        const startKey = body.start.date ||
            localDate(new Date(body.start.dateTime));

        if (startKey < todayKey) {
            const pastDate = new Date(startKey + "T12:00:00")
                .toLocaleDateString(undefined, {
                    year: "numeric",
                    month: "long",
                    day: "numeric"
                });

            const message =
                `The start date (${pastDate}) has already passed. ` +
                "Are you sure you still want to save this plan?";

            const confirmed = typeof window.northConfirm === "function"
                ? await window.northConfirm(message, {
                    title: "This plan is in the past",
                    confirmText: "Save anyway"
                })
                : window.confirm(message);

            if (!confirmed) return;
        }

        if (source === "local") {
            const plans = readLocalPlans();

            const local = {
                id: editingLocal
                    ? editingId
                    : "north-local-" + Date.now(),
                summary: body.summary,
                location: body.location,
                description: body.description,
                northCategory: [
                    "personal",
                    "study",
                    "work",
                    "health",
                    "other"
                ].includes(body.northCategory)
                    ? body.northCategory
                    : "other",
                northLocal: true,
                start: body.start,
                end: body.end
            };

            if (editingLocal) {
                const i = plans.findIndex(
                    (p) => p.id === editingId
                );

                if (i >= 0) {
                    plans[i] = local;
                } else {
                    plans.push(local);
                }
            } else {
                plans.push(local);
            }

            await writeLocalPlans(plans);
            $("event-modal").close();
            status("Plan saved and synced to your North account.");

        } else {
            if (!token) {
                throw new Error(
                    "Connect Google Calendar before saving a Google event."
                );
            }

            const calendarId = cfg().googleCalendarId || "primary";
            const selectedCategory = body.northCategory;
            delete body.northCategory;

            body.extendedProperties = {
                private: {
                    ...(editingId && !editingLocal
                        ? googleEvents.find((e) => e.id === editingId)
                            ?.extendedProperties?.private || {}
                        : {}),
                    northCategory: selectedCategory
                }
            };

            if (editingId && !editingLocal) {
                await gapi.client.calendar.events.update({
                    calendarId,
                    eventId: editingId,
                    resource: body
                });
            } else {
                await gapi.client.calendar.events.insert({
                    calendarId,
                    resource: body
                });
            }

            $("event-modal").close();
            await loadEvents();
        }

    } catch (e) {
        console.error(e);
        $("form-error").textContent =
            e.message || "Could not save this plan.";

    } finally {
        btn.disabled = false;
        btn.textContent = "Save plan";
    }
});
    $("delete-event").addEventListener("click", async () => {
        if (!editingId) return;
        if (editingLocal) {
            if (
                !(await window.northConfirm("This North-only plan will be removed from your North account.", {
                    title: "Delete this plan?",
                    confirmText: "Delete plan",
                    danger: true
                }))
            )
                return;
            try {
                await writeLocalPlans(readLocalPlans().filter((p) => p.id !== editingId));
                $("event-modal").close();
                status("North plan deleted and synced.");
            } catch (error) {
                $("form-error").textContent = error.message || "Could not delete this plan.";
            }
            return;
        }
        if (!token) return;
        if (
            !(await window.northConfirm("This event will be deleted from your Google Calendar.", {
                title: "Delete this event?",
                confirmText: "Delete event",
                danger: true
            }))
        )
            return;
        const btn = $("delete-event");
        btn.disabled = true;
        try {
            await gapi.client.calendar.events.delete({
                calendarId: cfg().googleCalendarId || "primary",
                eventId: editingId
            });
            $("event-modal").close();
            await loadEvents();
        } catch (e) {
            console.error(e);
            $("form-error").textContent = "Could not delete this event. Check your Google permission and try again.";
        } finally {
            btn.disabled = false;
        }
    });
    $("calendar-logout")?.addEventListener("click", async (event) => {
        event.preventDefault();
        const button = $("calendar-logout");
        if (button) {
            button.setAttribute("aria-disabled", "true");
            button.style.pointerEvents = "none";
        }
        try {
            if (plansUnsubscribe) plansUnsubscribe();
            await signOut(auth);
            sessionStorage.removeItem("north-user");
            localStorage.removeItem("north-remember-user");
            window.location.replace("login.html");
        } catch (error) {
            console.error("Calendar sign-out failed:", error);
            status("Could not sign out. Please try again.");
            if (button) {
                button.removeAttribute("aria-disabled");
                button.style.pointerEvents = "";
            }
        }
    });

    onAuthStateChanged(auth, (user) => {
        if (plansUnsubscribe) { plansUnsubscribe(); plansUnsubscribe = null; }
        currentUser = user || null;
        plansReady = false;
        if (!user) {
            window.location.replace("login.html");
            return;
        }
        // Keep the Google Calendar token/account cache isolated by Firebase UID.
        token = null;
        googleEvents = [];
        setConnected(false);
        paintAccount(readAccount());
        plansUnsubscribe = onSnapshot(
            doc(db, "users", user.uid),
            async (snapshot) => {
                const data = snapshot.exists() ? snapshot.data() : {};
                if (Array.isArray(data.calendarPlans)) {
                    localPlans = data.calendarPlans.map((plan) => ({ ...plan, northLocal: true }));
                    localStorage.setItem(`${LOCAL_KEY}-${user.uid}`, JSON.stringify(localPlans));
                } else {
                    try {
                        const cached = JSON.parse(localStorage.getItem(`${LOCAL_KEY}-${user.uid}`) || "[]");
                        localPlans = Array.isArray(cached) ? cached : [];
                    } catch { localPlans = []; }
                    // Older versions used one shared browser key. Ask before importing it
                    // so plans from another account are never silently transferred.
                    const promptKey = `north-calendar-legacy-prompted-${user.uid}`;
                    if (!localPlans.length && !localStorage.getItem(promptKey)) {
                        let legacy = [];
                        try {
                            const rawLegacy = JSON.parse(localStorage.getItem(LOCAL_KEY) || "[]");
                            legacy = Array.isArray(rawLegacy) ? rawLegacy : [];
                        } catch { legacy = []; }
                        if (legacy.length) {
                            localStorage.setItem(promptKey, "true");
                            const shouldImport = await window.northConfirm(
                                `Found ${legacy.length} older North plan(s) saved in shared browser storage. Import them into the currently signed-in North account?`,
                                { title: "Import older North plans?", confirmText: "Import plans" }
                            );
                            if (shouldImport) localPlans = legacy.map((plan) => ({ ...plan, northLocal: true }));
                        }
                    }
                }
                plansReady = true;
                combineEvents();
                render();
                if (!Array.isArray(data.calendarPlans) && localPlans.length) {
                    try { await writeLocalPlans(localPlans); }
                    catch (error) { console.error("Could not migrate this user's cached North plans:", error); status("North plans are cached locally; cloud sync failed."); }
                } else if (!Array.isArray(data.calendarPlans)) {
                    status("North plans will sync to your account when you create them.");
                }
            },
            (error) => {
                console.error("North calendar plan sync failed:", error);
                status("Could not sync North plans. Check your Firestore rules and connection.");
            }
        );
        restoreSavedToken();
    });
    combineEvents();
    paintAccount(readAccount());
    setInterval(
        () => {
            if (token) loadEvents();
        },
        5 * 60 * 1000
    );
    render();
    if (window.gapi && typeof window.northCalendarGapiLoaded === "function") window.northCalendarGapiLoaded();
    if (window.google?.accounts?.oauth2 && typeof window.northCalendarGisLoaded === "function") window.northCalendarGisLoaded();
})();
