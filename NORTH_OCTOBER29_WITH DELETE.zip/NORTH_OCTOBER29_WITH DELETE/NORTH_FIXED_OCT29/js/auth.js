import { auth, db, doc, getDoc, setDoc, serverTimestamp } from "./firebase.js";

import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  GoogleAuthProvider,
  signInWithPopup,
  updateProfile,
  signOut
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const message = document.getElementById("auth-message");
const cursorGlow = document.querySelector(".cursor-glow");

// UI: Cursor Glow Effect
if (cursorGlow && matchMedia("(hover:hover) and (pointer:fine)").matches) {
  addEventListener(
    "pointermove",
    (e) => {
      cursorGlow.style.left = e.clientX + "px";
      cursorGlow.style.top = e.clientY + "px";
    },
    { passive: true }
  );
}

// UI: Password Show/Hide Toggle
document.querySelectorAll("[data-toggle]").forEach((button) => {
  button.addEventListener("click", () => {
    const input = document.getElementById(button.dataset.toggle);
    const show = input.type === "password";
    input.type = show ? "text" : "password";
    button.textContent = show ? "HIDE" : "SHOW";
  });
});
// Helper: Save active user session for app.js
function setNorthSession(user) {
  const userData = {
    uid: user.uid,
    name: user.displayName || user.email?.split("@")[0] || "North User",
    email: user.email || ""
  };

  sessionStorage.setItem("north-user", JSON.stringify(userData));

  if (document.getElementById("remember")?.checked) {
    localStorage.setItem("north-remember-user", JSON.stringify(userData));
  }
}
// 1. Email/Password Login with a 24-hour lockout after 3 failed attempts

const LOGIN_MAX_ATTEMPTS = 3;
const LOGIN_LOCKOUT_MS = 24 * 60 * 60 * 1000;

function getLoginLockKey(email) {
  return "north-login-lock-" + email.trim().toLowerCase();
}

function readLoginLock(email) {
  try {
    return JSON.parse(
      localStorage.getItem(getLoginLockKey(email)) ||
      '{"failedAttempts":0,"lockoutUntil":0}'
    );
  } catch {
    return { failedAttempts: 0, lockoutUntil: 0 };
  }
}

function writeLoginLock(email, data) {
  localStorage.setItem(getLoginLockKey(email), JSON.stringify(data));
}

function clearLoginLock(email) {
  localStorage.removeItem(getLoginLockKey(email));
}

function showLoginLockout(lockoutUntil) {
  const unlockTime = new Date(lockoutUntil).toLocaleString();

  if (message) {
    message.textContent =
      `Sign-in is locked after 3 failed attempts. Try again after ${unlockTime}.`;
  }
}

const loginForm = document.getElementById("login-form");

if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    if (message) message.textContent = "";

    const email = document.getElementById("email").value.trim().toLowerCase();
    const password = document.getElementById("password").value;

    let lockData = readLoginLock(email);
    const now = Date.now();

    if (lockData.lockoutUntil > now) {
      showLoginLockout(lockData.lockoutUntil);
      return;
    }

    if (lockData.lockoutUntil && lockData.lockoutUntil <= now) {
      clearLoginLock(email);
      lockData = { failedAttempts: 0, lockoutUntil: 0 };
    }

    try {
      if (message) message.textContent = "Signing in…";

      const userCredential =
        await signInWithEmailAndPassword(auth, email, password);

      const user = userCredential.user;

      clearLoginLock(email);

      const registrationRef = doc(db, "users", user.uid);
      const registrationSnap = await getDoc(registrationRef);

      if (!registrationSnap.exists()) {
        await setDoc(registrationRef, {
          uid: user.uid,
          email: user.email || email,
          name: user.displayName || email.split("@")[0],
          authProvider: "password",
          createdAt: serverTimestamp()
        });
      }

      setNorthSession(user);
      location.href = "index.html";

    } catch (error) {
      console.error("Login error:", error);

      const isInvalidCredential = [
        "auth/invalid-credential",
        "auth/invalid-login-credentials",
        "auth/user-not-found",
        "auth/wrong-password"
      ].includes(error.code);

      if (isInvalidCredential) {
        lockData.failedAttempts =
          (Number(lockData.failedAttempts) || 0) + 1;

        if (lockData.failedAttempts >= LOGIN_MAX_ATTEMPTS) {
          lockData.lockoutUntil = Date.now() + LOGIN_LOCKOUT_MS;
          writeLoginLock(email, lockData);
          showLoginLockout(lockData.lockoutUntil);
        } else {
          writeLoginLock(email, lockData);

          if (message) {
            const remaining =
              LOGIN_MAX_ATTEMPTS - lockData.failedAttempts;

            message.textContent =
              `Email or password is incorrect. ` +
              `Attempt ${lockData.failedAttempts} of ${LOGIN_MAX_ATTEMPTS}. ` +
              `${remaining} attempt${remaining === 1 ? "" : "s"} remaining ` +
              `before a 24-hour lockout.`;
          }
        }

      } else if (error.code === "auth/too-many-requests") {
  if (message) {
    message.textContent =
      "Firebase has temporarily blocked sign-in attempts. Please wait before trying again.";
  }

      } else {
        if (message) {
          message.textContent = "Sign-in failed: " + error.message;
        }
      }
    }
  });
}
// 2. Account Creation (Signup)
const signupForm = document.getElementById("signup-form");

if (signupForm) {
  signupForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (message) message.textContent = "";

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim().toLowerCase();
    const password = document.getElementById("password").value;

    try {
      if (message) message.textContent = "Creating account…";

      const userCredential = await createUserWithEmailAndPassword(auth, email, password);

      const user = userCredential.user;

      if (name) {
        await updateProfile(user, { displayName: name });
      }

      // Save North registration under this user's Firebase UID.
      await setDoc(doc(db, "users", user.uid), {
        uid: user.uid,
        email: user.email || email,
        name: name || user.displayName || email.split("@")[0],
        authProvider: "password",
        createdAt: serverTimestamp()
      });

      setNorthSession(user);

      if (message) {
        message.textContent = "Account created! Opening North…";
      }

      setTimeout(() => {
        location.href = "index.html";
      }, 650);
    } catch (error) {
      console.error("Signup error:", error);

      if (message) {
        if (error.code === "auth/email-already-in-use") {
          message.textContent = "An account with this email already exists.";
        } else {
          message.textContent = "Signup failed: " + error.message;
        }
      }
    }
  });
}
// 3. Google Sign-In Handler — registered North accounts only
const googleBtn = document.getElementById("google-login-btn");

if (googleBtn) {
  googleBtn.addEventListener("click", async () => {
    const provider = new GoogleAuthProvider();

    try {
      if (message) {
        message.textContent = "Connecting to Google…";
      }

      const result = await signInWithPopup(auth, provider);

      // Check whether this user has registered with North.
      const registrationRef = doc(db, "users", result.user.uid);
      const registrationSnap = await getDoc(registrationRef);

      if (!registrationSnap.exists()) {
        await signOut(auth);

        if (message) {
          message.textContent = "No North account found. Please sign up with Google first.";
        }

        return;
      }

      setNorthSession(result.user);
      location.href = "index.html";
    } catch (error) {
      console.error("Google sign-in error:", error);

      if (message) {
        if (error.code === "auth/popup-closed-by-user") {
          message.textContent = "Sign-in popup closed before completion.";
        } else {
          message.textContent = "Google sign-in failed: " + error.message;
        }
      }
    }
  });
}

// 4. Google Sign-Up Handler — register new North accounts
const googleSignupBtn = document.getElementById("google-signup-btn");

if (googleSignupBtn) {
  googleSignupBtn.addEventListener("click", async () => {
    const provider = new GoogleAuthProvider();

    try {
      if (message) {
        message.textContent = "Connecting to Google…";
      }

      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      const registrationRef = doc(db, "users", user.uid);
      const registrationSnap = await getDoc(registrationRef);

      // An account already registered with North should use Login.
      if (registrationSnap.exists()) {
        await signOut(auth);

        if (message) {
          message.textContent = "This North account already exists. Please sign in instead.";
        }

        return;
      }

      // Register this user with North.
      await setDoc(registrationRef, {
        uid: user.uid,
        email: user.email || "",
        name: user.displayName || user.email?.split("@")[0] || "North User",
        authProvider: "google",
        createdAt: serverTimestamp()
      });

      setNorthSession(user);

      if (message) {
        message.textContent = "Account created! Opening North…";
      }

      setTimeout(() => {
        location.href = "index.html";
      }, 650);
    } catch (error) {
      console.error("Google signup error:", error);

      if (message) {
        message.textContent = "Google signup failed: " + error.message;
      }
    }
  });
}

/* 5. Forgot Password */
const forgotPasswordBtn = document.getElementById("forgot-password-btn");

if (forgotPasswordBtn) {
  forgotPasswordBtn.addEventListener("click", async () => {
    const emailInput = document.getElementById("email");
    const email = emailInput?.value.trim().toLowerCase();

    if (!email) {
      if (message) {
        message.textContent = "Enter your email address first.";
      }
      emailInput?.focus();
      return;
    }

    try {
      forgotPasswordBtn.disabled = true;

      if (message) {
        message.textContent = "Sending password reset email…";
      }

      await sendPasswordResetEmail(auth, email);

      if (message) {
        message.textContent =
          "If an account exists for this email, a password reset link will be sent. Check your inbox and spam folder.";
      }
    } catch (error) {
      console.error("Password reset error:", error);

      if (message) {
        message.textContent =
          "Unable to send the reset email. Check the address and try again later.";
      }
    } finally {
      forgotPasswordBtn.disabled = false;
    }
  });
}
