import {
  db,
  auth,
  onAuthStateChanged,
  collection,
  addDoc,
  serverTimestamp,
  doc,
  getDoc,
  setDoc,
  onSnapshot
} from "./firebase.js";

import {
  signOut,
  updateProfile,
  updateEmail,
  updatePassword,
  reauthenticateWithCredential,
  reauthenticateWithPopup,
  EmailAuthProvider,
  GoogleAuthProvider
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const $ = (id) => document.getElementById(id);

async function recordLogin(user) {
  const sessionKey = `logged_session_${user.uid}`;
  if (sessionStorage.getItem(sessionKey)) return;

  try {
    await addDoc(collection(db, "user_logins"), {
      uid: user.uid,
      email: user.email || "",
      name: user.displayName || (user.email ? user.email.split("@")[0] : "North User"),
      loginTime: serverTimestamp()
    });
    sessionStorage.setItem(sessionKey, "true");
    console.log("Recorded login entry in user_logins");
  } catch (error) {
    console.error("Error writing to user_logins:", error);
  }
}

let user = null;
try {
  user = JSON.parse(sessionStorage.getItem("north-user") || localStorage.getItem("north-remember-user") || "null");
} catch {}

// User-scoped storage helper to prevent account data bleeding between users
const getUserPrefix = () => {
  if (user && user.email) return "north-" + user.email.toLowerCase().replace(/[^a-zA-Z0-9]/g, "_") + "-";
  if (user && user.name) return "north-" + user.name.toLowerCase().replace(/[^a-zA-Z0-9]/g, "_") + "-";
  return "north-guest-";
};

const getPicKey = () =>
  user && user.email ? "north-pic-" + user.email.toLowerCase().replace(/[^a-zA-Z0-9]/g, "_") : "north-profile-picture";

const storage = {
  get(key, fallback) {
    try {
      const v = localStorage.getItem(getUserPrefix() + key);
      return v === null ? fallback : JSON.parse(v);
    } catch {
      return fallback;
    }
  },
  set(key, value) {
    localStorage.setItem(getUserPrefix() + key, JSON.stringify(value));
  }
};

const NORTH_THEME_KEY = "north-theme";
function applyNorthTheme(theme) {
  const value = theme === "light" ? "light" : "dark";
  document.documentElement.dataset.northTheme = value;
  document.body.dataset.northTheme = value;
  const select = document.getElementById("north-theme-select");
  if (select && select.value !== value) select.value = value;
}
applyNorthTheme(localStorage.getItem(NORTH_THEME_KEY) || "dark");
window.addEventListener("storage", (e) => {
  if (e.key === NORTH_THEME_KEY) applyNorthTheme(e.newValue || "dark");
});
window.northSaveThemePreference = async function (theme) {
  const value = theme === "light" ? "light" : "dark";

  localStorage.setItem(NORTH_THEME_KEY, value);
  applyNorthTheme(value);

  const firebaseUser = auth.currentUser;
  if (!firebaseUser) return;

  try {
    await setDoc(
      doc(db, "users", firebaseUser.uid),
      {
        theme: value,
        updatedAt: serverTimestamp()
      },
      { merge: true }
    );

    const status = $("theme-saved");
    if (status) status.textContent = "Theme saved and synced to your North account.";
  } catch (error) {
    console.error("Could not sync North theme preference:", error);

    const status = $("theme-saved");
    if (status) status.textContent = "Theme saved on this device; cloud sync failed.";
  }
};

function readProfilePicture() {
  try {
    return localStorage.getItem(getPicKey()) || "";
  } catch {
    return "";
  }
}
function paintAvatar(el, name) {
  if (!el) return;
  const pic = readProfilePicture();
  if (pic) {
    el.textContent = "";
    el.style.backgroundImage = "url(" + JSON.stringify(pic) + ")";
    el.classList.add("avatar-with-image");
  } else {
    el.style.backgroundImage = "";
    el.classList.remove("avatar-with-image");
    el.textContent = ((name || "North").trim()[0] || "N").toUpperCase();
  }
}
function compressProfilePicture(dataUrl) {
  return new Promise((resolve, reject) => {
    const image = new Image();

    image.onload = () => {
      try {
        const maxSize = 320;
        const scale = Math.min(1, maxSize / Math.max(image.naturalWidth, image.naturalHeight));

        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));

        const context = canvas.getContext("2d");
        if (!context) {
          reject(new Error("Could not process the profile picture."));
          return;
        }

        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(image, 0, 0, canvas.width, canvas.height);

        const compressed = canvas.toDataURL("image/jpeg", 0.75);

        if (compressed.length > 800000) {
          reject(new Error("Image is still too large. Please choose another image."));
          return;
        }

        resolve(compressed);
      } catch (error) {
        reject(error);
      }
    };

    image.onerror = () => {
      reject(new Error("Could not read this profile picture."));
    };

    image.src = dataUrl;
  });
}
let pendingProfilePicture = undefined;
function setupProfilePicture() {
  const input = $("profile-picture-input");
  const preview = $("profile-picture-preview");
  const remove = $("remove-profile-picture");
  const key = getPicKey();
  const paintPreview = () => {
    const pic = pendingProfilePicture !== undefined ? pendingProfilePicture : readProfilePicture();
    if (preview) {
      preview.style.backgroundImage = pic ? 'url("' + pic + '")' : "";
      preview.classList.toggle("avatar-with-image", !!pic);
      preview.textContent = pic ? "" : ((user?.name || "N")[0] || "N").toUpperCase();
    }
    paintAvatar($("avatar"), user?.name);
    paintAvatar($("north-account-avatar"), user?.name);
  };
  if (input && !input.dataset.northBound) {
    input.dataset.northBound = "1";
    input.addEventListener("change", () => {
      const file = input.files && input.files[0];
      if (!file) return;
      if (!file.type.startsWith("image/")) return;
      if (file.size > 2 * 1024 * 1024) {
        alert("Please choose an image smaller than 2 MB.");
        input.value = "";
        return;
      }

      const reader = new FileReader();
      reader.onload = async () => {
        try {
          pendingProfilePicture = await compressProfilePicture(String(reader.result));
          paintPreview();
          const st = $("profile-settings-status");
          if (st) st.textContent = "Picture preview ready. Save account settings to apply it.";
        } catch (e) {
          alert("This image is too large to save. Please choose a smaller image.");
        }
      };
      reader.readAsDataURL(file);
    });
  }
  if (remove && !remove.dataset.northBound) {
    remove.dataset.northBound = "1";
    remove.addEventListener("click", () => {
      pendingProfilePicture = "";
      if (input) input.value = "";
      paintPreview();
      const st = $("profile-settings-status");
      if (st) st.textContent = "Picture removal pending. Save account settings to apply it.";
    });
  }
  paintPreview();
}

// Keep profile details synchronized between North pages in the same browser.
window.addEventListener("storage", (event) => {
  if (event.key === "north-profile-name" && event.newValue) {
    user = { ...(user || {}), name: event.newValue };
    paintNorthUser();
  }
  if (event.key === "north-profile-email" && event.newValue) {
    user = { ...(user || {}), email: event.newValue };
    paintNorthUser();
  }
  if (event.key === getPicKey()) {
    paintNorthUser();
    setupProfilePicture();
  }
});

function paintNorthUser() {
  if (!user) return;
  // Keep the account settings fields populated.
const settingsName = $("settings-username");
if (settingsName && document.activeElement !== settingsName) {
  settingsName.value = user.name || auth.currentUser?.displayName || "";
}

const settingsEmail = $("settings-email");
if (settingsEmail && document.activeElement !== settingsEmail) {
  settingsEmail.value = user.email || auth.currentUser?.email || "";
}
  if ($("userName")) $("userName").textContent = user.name;
  if ($("userEmail")) $("userEmail").textContent = user.email || "";
  paintAvatar($("avatar"), user.name);
  if ($("north-account-name")) $("north-account-name").textContent = user.name;
  if ($("north-account-email")) $("north-account-email").textContent = user.email || "";
  if ($("north-account-avatar")) paintAvatar($("north-account-avatar"), user.name);
}

if (!user) {
  location.replace("login.html");
} else {
  paintNorthUser();
  setupProfilePicture();
}

const cursorGlow = document.querySelector(".cursor-glow");
if (cursorGlow && matchMedia("(hover:hover) and (pointer:fine)").matches)
  addEventListener(
    "pointermove",
    (e) => {
      cursorGlow.style.left = e.clientX + "px";
      cursorGlow.style.top = e.clientY + "px";
    },
    { passive: true }
  );
function updateClock() {
  const now = new Date(),
    hour = now.getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  if ($("greeting")) $("greeting").textContent = `${greeting}, ${(user?.name || "there").split(" ")[0]} 👋`;
  if ($("current-date"))
    $("current-date").textContent = now.toLocaleDateString(undefined, {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric"
    });
  if ($("current-time"))
    $("current-time").textContent = now.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
  if ($("today-label"))
    $("today-label").textContent = now.toLocaleDateString(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric"
    });
}
updateClock();
setInterval(updateClock, 1000);
let weatherRefreshTimer = null;
let currentWeatherCoordinates = null;

const weatherLabels = {
  0: ["Clear sky", "☀️"],
  1: ["Mainly clear", "🌤️"],
  2: ["Partly cloudy", "⛅"],
  3: ["Overcast", "☁️"],
  45: ["Foggy", "🌫️"],
  48: ["Foggy", "🌫️"],
  51: ["Light drizzle", "🌦️"],
  53: ["Drizzle", "🌦️"],
  55: ["Heavy drizzle", "🌧️"],
  61: ["Light rain", "🌦️"],
  63: ["Rain", "🌧️"],
  65: ["Heavy rain", "🌧️"],
  71: ["Light snow", "🌨️"],
  73: ["Snow", "🌨️"],
  75: ["Heavy snow", "❄️"],
  80: ["Rain showers", "🌦️"],
  81: ["Rain showers", "🌧️"],
  82: ["Heavy showers", "🌧️"],
  95: ["Thunderstorm", "⛈️"],
  96: ["Thunderstorm with hail", "⛈️"],
  99: ["Severe thunderstorm", "⛈️"]
};

function setWeatherMessage(message) {
  if ($("weather-summary")) $("weather-summary").textContent = message;
  if ($("weather-condition")) $("weather-condition").textContent = message;
}

async function updateWeather(lat, lon) {
  try {
    const url = new URL("https://api.open-meteo.com/v1/forecast");

    url.searchParams.set("latitude", lat);
    url.searchParams.set("longitude", lon);
    url.searchParams.set(
      "current",
      "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m"
    );
    url.searchParams.set("hourly", "precipitation_probability");
    url.searchParams.set("forecast_days", "1");
    url.searchParams.set("timezone", "auto");

    const response = await fetch(url, { cache: "no-store" });

    if (!response.ok) {
      throw new Error(`Weather request failed: ${response.status}`);
    }

    const data = await response.json();
    const current = data.current;
    const code = current.weather_code;
    const [description, emoji] = weatherLabels[code] || ["Current conditions", "🌤️"];

    const temperature = current.temperature_2m;
    const feelsLike = current.apparent_temperature;
    const humidity = current.relative_humidity_2m;
    const wind = current.wind_speed_10m;

    if ($("weather-icon")) $("weather-icon").textContent = emoji;
    if ($("weather-temp")) $("weather-temp").textContent = `${Math.round(temperature)}°C`;
    if ($("weather-condition")) $("weather-condition").textContent = description;
    if ($("weather-summary")) $("weather-summary").textContent = `${Math.round(temperature)}°C · ${description}`;

    const details = [];

    if (Number.isFinite(feelsLike)) {
      details.push(`Feels like ${Math.round(feelsLike)}°C`);
    }

    if (Number.isFinite(humidity)) {
      details.push(`Humidity ${humidity}%`);
    }

    if (Number.isFinite(wind)) {
      details.push(`Wind ${Math.round(wind)} km/h`);
    }

    details.push(`Updated ${new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`);
    if ($("weather-extra")) $("weather-extra").textContent = details.join(" · ");
  } catch (error) {
    console.error("North weather:", error);
    setWeatherMessage("Weather unavailable");
    if ($("weather-extra")) $("weather-extra").textContent = "Check your internet connection and location permission.";
  }
}

function requestWeatherLocation() {
  const savedLocationKey = "north-weather-coordinates";
  try {
    const saved = JSON.parse(localStorage.getItem(savedLocationKey) || "null");
    if (saved && Number.isFinite(saved.lat) && Number.isFinite(saved.lon)) {
      currentWeatherCoordinates = { lat: saved.lat, lon: saved.lon };
      updateWeather(saved.lat, saved.lon);
      if (weatherRefreshTimer) clearInterval(weatherRefreshTimer);
      weatherRefreshTimer = setInterval(
        () => {
          if (currentWeatherCoordinates) {
            updateWeather(currentWeatherCoordinates.lat, currentWeatherCoordinates.lon);
          }
        },
        10 * 60 * 1000
      );
      return;
    }
  } catch (error) {
    console.warn("North saved weather location could not be read:", error);
  }

  if (!navigator.geolocation) {
    setWeatherMessage("Location is not supported");
    return;
  }

  setWeatherMessage("Getting your location for weather…");

  navigator.geolocation.getCurrentPosition(
    (position) => {
      currentWeatherCoordinates = {
        lat: position.coords.latitude,
        lon: position.coords.longitude
      };
      try {
        localStorage.setItem(savedLocationKey, JSON.stringify(currentWeatherCoordinates));
      } catch (error) {
        console.warn("North could not save weather location:", error);
      }

      updateWeather(currentWeatherCoordinates.lat, currentWeatherCoordinates.lon);
      if (weatherRefreshTimer) clearInterval(weatherRefreshTimer);
      weatherRefreshTimer = setInterval(
        () => {
          if (currentWeatherCoordinates) {
            updateWeather(currentWeatherCoordinates.lat, currentWeatherCoordinates.lon);
          }
        },
        10 * 60 * 1000
      );
    },
    (error) => {
      console.warn("North location permission:", error.message);
      currentWeatherCoordinates = { lat: 13.9419, lon: 121.1644 };
      updateWeather(currentWeatherCoordinates.lat, currentWeatherCoordinates.lon);
      if (weatherRefreshTimer) clearInterval(weatherRefreshTimer);
      weatherRefreshTimer = setInterval(
        () => {
          if (currentWeatherCoordinates) {
            updateWeather(currentWeatherCoordinates.lat, currentWeatherCoordinates.lon);
          }
        },
        10 * 60 * 1000
      );
    },
    { enableHighAccuracy: false, timeout: 12000, maximumAge: 60 * 60 * 1000 }
  );
}
requestWeatherLocation();
addEventListener("focus", () => {
  if (currentWeatherCoordinates) updateWeather(currentWeatherCoordinates.lat, currentWeatherCoordinates.lon);
});
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && currentWeatherCoordinates)
    updateWeather(currentWeatherCoordinates.lat, currentWeatherCoordinates.lon);
});

let tasks = storage.get("tasks", []),
  schedule = storage.get("schedule", []);
function saveTasks() {
  storage.set("tasks", tasks);
  renderTasks();
  void saveNorthCloudData();
}
function renderTasks() {
  const list = $("task-list");
  if (!list) return;
  list.innerHTML = "";
  if (!tasks.length) list.innerHTML = '<p class="empty-state">Your list is clear. Add your first task.</p>';
  tasks.forEach((task, i) => {
    const row = document.createElement("div");
    row.className = "task-item" + (task.done ? " done" : "");
    const label = document.createElement("label");
    label.className = "task-label";
    const check = document.createElement("input");
    check.type = "checkbox";
    check.checked = task.done;
    check.addEventListener("change", () => {
      tasks[i].done = check.checked;
      saveTasks();
    });
    const text = document.createElement("span");
    text.className = "task-text";
    text.textContent = task.text || task.name || task.title || "Untitled task";
    label.append(check, text);
    const del = document.createElement("button");
    del.className = "icon-btn";
    del.textContent = "✕";
    del.setAttribute("aria-label", "Delete task");
    del.addEventListener("click", () => {
      tasks.splice(i, 1);
      saveTasks();
    });
    row.append(label, del);
    list.append(row);
  });
  const done = tasks.filter((t) => t.done).length;
  if ($("task-total")) $("task-total").textContent = `${tasks.length} item${tasks.length === 1 ? "" : "s"}`;
  if ($("progress-count")) $("progress-count").textContent = `${done} / ${tasks.length}`;
  if ($("progress-fill")) $("progress-fill").style.width = (tasks.length ? (done / tasks.length) * 100 : 0) + "%";
  if ($("progress-caption"))
    $("progress-caption").textContent = tasks.length
      ? `${Math.round((done / tasks.length) * 100)}% complete. Keep going!`
      : "Add a task to get started.";
  if ($("stats-done")) $("stats-done").textContent = done;
}
function renderSchedule() {
  const list = $("schedule-list");
  if (!list) return;

  list.innerHTML = "";

  if (!schedule.length) {
    list.innerHTML = '<p class="empty-state">No plans yet. Add a class, appointment, or reminder below.</p>';
    return;
  }

  schedule.sort((a, b) => String(a.time || "").localeCompare(String(b.time || "")));

  schedule.forEach((item, i) => {
    const row = document.createElement("div");
    row.className = "schedule-item";

    const time = document.createElement("span");
    time.className = "schedule-time";

    const parsedTime = new Date(`2000-01-01T${item.time}`);

    time.textContent = Number.isNaN(parsedTime.getTime())
      ? String(item.time || "")
      : parsedTime.toLocaleTimeString([], {
          hour: "numeric",
          minute: "2-digit"
        });

    const name = document.createElement("span");
    name.className = "schedule-subject";
    name.textContent = item.title || "";
    name.style.flex = "1";

    const del = document.createElement("button");
    del.className = "icon-btn";
    del.textContent = "✕";
    del.setAttribute("aria-label", "Delete schedule item");

    del.addEventListener("click", () => {
      schedule.splice(i, 1);
      storage.set("schedule", schedule);
      renderSchedule();
      void saveNorthCloudData();
    });

    row.append(time, name, del);
    list.append(row);
  });
}

$("schedule-form")?.addEventListener("submit", (e) => {
  e.preventDefault();

  const title = $("schedule-title")?.value.trim();
  const time = $("schedule-time")?.value;

  if (!title || !time) return;

  schedule.push({ title, time });

  storage.set("schedule", schedule);
  $("schedule-title").value = "";

  renderSchedule();
  void saveNorthCloudData();
});

renderSchedule();

// NOTES — local cache and dedicated cloud sync
const notesInput = $("notes-input");

if (notesInput) {
  notesInput.value = storage.get("notes", "");
}

let noteTimer = null;
let notesDirty = false;

notesInput?.addEventListener("input", () => {
  notesDirty = true;

  const status = $("notes-status");
  if (status) status.textContent = "Saving…";

  clearTimeout(noteTimer);

  noteTimer = setTimeout(() => {
    const value = notesInput.value;
    storage.set("notes", value);
    void saveNorthNotesToCloud(value);
  }, 300);
});

notesInput?.addEventListener("blur", () => {
  if (!notesDirty) return;

  clearTimeout(noteTimer);

  const value = notesInput.value;
  storage.set("notes", value);
  void saveNorthNotesToCloud(value);
});

// FOCUS TIMER — restored from the previous working version
let focusDuration = Number(storage.get("focus-duration-seconds", 60));

if (!Number.isFinite(focusDuration) || focusDuration < 1) {
  focusDuration = 60;
}

let seconds = focusDuration;
let timer = null;

const focusMinutesDisplay = $("focus-minutes-display");

function syncFocusControls() {
  if (focusMinutesDisplay) {
    focusMinutesDisplay.textContent = String(Math.floor(focusDuration / 60));
  }

  const hours = $("focus-hours");
  const mins = $("focus-custom-minutes");
  const secs = $("focus-custom-seconds");

  if (hours) hours.value = String(Math.floor(focusDuration / 3600));
  if (mins) mins.value = String(Math.floor((focusDuration % 3600) / 60));
  if (secs) secs.value = String(focusDuration % 60);
}

function drawTimer() {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;

  const display = $("focus-time");
  if (!display) return;

  display.textContent = `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function stopTimer() {
  clearInterval(timer);
  timer = null;
}

// NORTH FOCUS ALARM — custom MP3 and selectable synthesized sounds
let alarmContext = null;
let alarmNodes = [];
let alarmAudio = null;
let alarmPatternTimer = null;

const focusAlarmSelect = $("focus-alarm-sound");
const focusAlarmStatus = $("focus-alarm-status");

const alarmSoundLabels = {
  custom: "My custom MP3",
  classic: "Classic two-tone",
  gentle: "Gentle chime",
  digital: "Digital beeps",
  pulse: "Soft pulse"
};

const validAlarmSounds = Object.keys(alarmSoundLabels);

if (focusAlarmSelect) {
  const savedSound = storage.get("focus-alarm-sound", "custom");

  focusAlarmSelect.value = validAlarmSounds.includes(savedSound) ? savedSound : "custom";
}

function playAlarmPattern(mode) {
  const AudioCtx = window.AudioContext || window.webkitAudioContext;

  if (!AudioCtx) return false;

  if (!alarmContext || alarmContext.state === "closed") {
    alarmContext = new AudioCtx();
  }

  if (alarmContext.state === "suspended") {
    void alarmContext.resume();
  }

  const patterns = {
    classic: [
      { frequency: 660, duration: 0.32, gap: 0.12, type: "square" },
      { frequency: 880, duration: 0.32, gap: 0.28, type: "square" }
    ],
    gentle: [
      { frequency: 784, duration: 0.48, gap: 0.1, type: "sine" },
      { frequency: 988, duration: 0.55, gap: 0.2, type: "sine" },
      { frequency: 1175, duration: 0.6, gap: 0.3, type: "sine" }
    ],
    digital: [
      { frequency: 1046, duration: 0.12, gap: 0.1, type: "square" },
      { frequency: 784, duration: 0.12, gap: 0.1, type: "square" },
      { frequency: 1046, duration: 0.18, gap: 0.3, type: "square" }
    ],
    pulse: [{ frequency: 523, duration: 0.7, gap: 0.3, type: "sine" }]
  };

  const pattern = patterns[mode] || patterns.classic;
  let offset = 0;
  const startTime = alarmContext.currentTime;

  pattern.forEach((tone) => {
    const oscillator = alarmContext.createOscillator();
    const gain = alarmContext.createGain();

    oscillator.type = tone.type;
    oscillator.frequency.value = tone.frequency;

    const toneStart = startTime + offset;
    const toneEnd = toneStart + tone.duration;

    gain.gain.setValueAtTime(0.0001, toneStart);
    gain.gain.exponentialRampToValueAtTime(0.12, toneStart + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, toneEnd);

    oscillator.connect(gain);
    gain.connect(alarmContext.destination);

    const node = { oscillator, gain };
    alarmNodes.push(node);

    oscillator.addEventListener(
      "ended",
      () => {
        alarmNodes = alarmNodes.filter((item) => item !== node);

        try {
          oscillator.disconnect();
          gain.disconnect();
        } catch {}
      },
      { once: true }
    );

    oscillator.start(toneStart);
    oscillator.stop(toneEnd + 0.02);

    offset += tone.duration + tone.gap;
  });

  return true;
}

function startSynthAlarm(mode) {
  const intervals = {
    classic: 1400,
    gentle: 1900,
    digital: 1300,
    pulse: 1500
  };

  if (!playAlarmPattern(mode)) {
    if (focusAlarmStatus) {
      focusAlarmStatus.textContent = "Alarm audio is not supported in this browser.";
    }
    return;
  }

  alarmPatternTimer = setInterval(() => {
    playAlarmPattern(mode);
  }, intervals[mode] || intervals.classic);

  if (focusAlarmStatus) {
    focusAlarmStatus.textContent = `Playing: ${alarmSoundLabels[mode]}.`;
  }
}

function ringAlarm({ test = false } = {}) {
  stopAlarm();

  const mode = validAlarmSounds.includes(focusAlarmSelect?.value)
    ? focusAlarmSelect.value
    : storage.get("focus-alarm-sound", "custom");

  if (mode === "custom") {
    const audio = new Audio("./sounds/focus-alarm.mp3");

    audio.loop = true;
    audio.volume = 0.8;
    alarmAudio = audio;

    audio
      .play()
      .then(() => {
        if (focusAlarmStatus) {
          focusAlarmStatus.textContent = test
            ? "Playing your custom alarm. Press Stop sound to end it."
            : "Focus complete — playing your custom alarm.";
        }
      })
      .catch((error) => {
        console.warn("Custom Focus alarm could not play:", error);

        if (alarmAudio !== audio) return;

        stopAlarm();

        if (focusAlarmStatus) {
          focusAlarmStatus.textContent = "Custom MP3 unavailable. Using the Classic alarm instead.";
        }

        startSynthAlarm("classic");
      });
  } else {
    startSynthAlarm(mode);
  }

  if (!test) {
    document.dispatchEvent(new CustomEvent("north:timer-complete"));
  }
}

function stopAlarm() {
  if (alarmPatternTimer !== null) {
    clearInterval(alarmPatternTimer);
    alarmPatternTimer = null;
  }

  if (alarmAudio) {
    alarmAudio.pause();
    alarmAudio.currentTime = 0;
    alarmAudio = null;
  }

  alarmNodes.forEach(({ oscillator, gain }) => {
    try {
      gain.gain.setValueAtTime(0, alarmContext?.currentTime || 0);
      oscillator.stop();
    } catch {}
  });

  alarmNodes = [];

  if (alarmContext) {
    try {
      void alarmContext.close();
    } catch {}

    alarmContext = null;
  }
}

focusAlarmSelect?.addEventListener("change", () => {
  const selected = focusAlarmSelect.value;

  storage.set("focus-alarm-sound", selected);

  if (focusAlarmStatus) {
    focusAlarmStatus.textContent = `${alarmSoundLabels[selected]} selected. Use Test sound to preview it.`;
  }
});

$("focus-alarm-test")?.addEventListener("click", () => {
  ringAlarm({ test: true });
});

$("focus-alarm-stop")?.addEventListener("click", () => {
  stopAlarm();

  if (focusAlarmStatus) {
    focusAlarmStatus.textContent = "Alarm stopped.";
  }
});

document.addEventListener("north:alarm-stop", stopAlarm);
// Save completed Dashboard focus sessions to the signed-in North account.
async function saveDashboardFocusSession() {
  const savingUserId = northCloudUserId;

  if (!northCloudReady || !savingUserId || auth.currentUser?.uid !== savingUserId) {
    console.warn("North focus session could not be saved: account not ready.");
    return;
  }

  try {
    const userRef = doc(db, "users", savingUserId);
    const snapshot = await getDoc(userRef);

    if (auth.currentUser?.uid !== savingUserId) return;

    const data = snapshot.exists() ? snapshot.data() : {};
    const existingSessions = Array.isArray(data.focusSessions) ? data.focusSessions : [];

    const session = {
      id: `dashboard-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      mode: "focus",
      durationSeconds: focusDuration,
      completedAt: new Date().toISOString()
    };

    await setDoc(
      userRef,
      {
        focusSessions: [session, ...existingSessions].slice(0, 500),
        updatedAt: serverTimestamp()
      },
      { merge: true }
    );

    if (auth.currentUser?.uid === savingUserId && $("focus-caption")) {
      $("focus-caption").textContent = "Session complete. Saved to your North account.";
    }
  } catch (error) {
    console.error("Could not save Dashboard focus session:", error);

    if ($("focus-caption")) {
      $("focus-caption").textContent = "Session complete, but saving failed. Check your connection.";
    }
  }
}

function clearCustomInvalid() {
  document.querySelectorAll("#focus .focus-custom-fields input").forEach((input) => {
    input.classList.remove("invalid", "input-error", "is-invalid");
    input.removeAttribute("aria-invalid");
    input.style.outline = "";
    input.style.borderColor = "";
  });
}

function applyFocusDuration(value) {
  value = Number(value);

  if (!Number.isFinite(value) || value < 1 || value > 14399) {
    const caption = $("focus-caption");

    if (caption) {
      caption.textContent = "Choose a duration of at least one second and no more than 3:59:59.";
    }

    return false;
  }

  focusDuration = Math.floor(value);

  storage.set("focus-duration-seconds", focusDuration);
  storage.set("focus-duration-minutes", Math.ceil(focusDuration / 60));

  stopTimer();
  seconds = focusDuration;

  syncFocusControls();
  drawTimer();
  clearCustomInvalid();

  const startButton = $("focus-start");
  const caption = $("focus-caption");

  if (startButton) startButton.textContent = "Start focus";

  if (caption) {
    caption.textContent = `Timer set for ${String(Math.floor(focusDuration / 3600)).padStart(2, "0")}:${String(Math.floor((focusDuration % 3600) / 60)).padStart(2, "0")}:${String(focusDuration % 60).padStart(2, "0")}.`;
  }

  void saveNorthCloudData();
  return true;
}

$("focus-minus")?.addEventListener("click", () => {
  applyFocusDuration(Math.max(1, focusDuration - 60));
});

$("focus-plus")?.addEventListener("click", () => {
  applyFocusDuration(Math.min(14399, focusDuration + 60));
});

$("focus-custom-apply")?.addEventListener("click", () => {
  const h = Number($("focus-hours").value);
  const m = Number($("focus-custom-minutes").value);
  const sec = Number($("focus-custom-seconds").value);

  const inputs = [$("focus-hours"), $("focus-custom-minutes"), $("focus-custom-seconds")];

  clearCustomInvalid();

  if (
    !Number.isInteger(h) ||
    !Number.isInteger(m) ||
    !Number.isInteger(sec) ||
    h < 0 ||
    h > 3 ||
    m < 0 ||
    m > 59 ||
    sec < 0 ||
    sec > 59
  ) {
    inputs.forEach((input) => {
      if (!input) return;

      input.classList.add("invalid");
      input.setAttribute("aria-invalid", "true");
      input.style.borderColor = "#ff667a";
      input.style.outline = "1px solid rgba(255,102,122,.35)";
    });

    const caption = $("focus-caption");
    if (caption) caption.textContent = "Enter valid hours, minutes, and seconds.";

    return;
  }

  const total = h * 3600 + m * 60 + sec;

  if (total < 1) {
    const caption = $("focus-caption");
    if (caption) caption.textContent = "Set a time of at least one second.";
    return;
  }

  applyFocusDuration(total);
});

$("focus-start")?.addEventListener("click", () => {
  const startButton = $("focus-start");
  const caption = $("focus-caption");

  if (timer) {
    stopTimer();

    if (startButton) startButton.textContent = "Resume focus";
    if (caption) caption.textContent = "Paused. Take a breath.";

    return;
  }

  if (seconds <= 0) {
    if (startButton) {
      startButton.classList.remove("shake");
      void startButton.offsetWidth;
      startButton.classList.add("shake");

      setTimeout(() => startButton.classList.remove("shake"), 500);
    }

    if (caption) caption.textContent = "Set a time before starting.";
    return;
  }

  if (startButton) startButton.textContent = "Pause";
  if (caption) caption.textContent = "One thing at a time. You’ve got this.";

  timer = setInterval(() => {
    seconds--;
    drawTimer();

    if (seconds <= 0) {
      stopTimer();
      seconds = 0;
      drawTimer();

      if (caption) caption.textContent = "Session complete. Time for a break!";

      if (startButton) startButton.textContent = "Start again";

      ringAlarm();

      void saveDashboardFocusSession();

      if ("Notification" in window && Notification.permission === "granted") {
        new Notification("North focus session complete");
      }
    }
  }, 1000);
});

$("focus-reset")?.addEventListener("click", () => {
  stopTimer();
  stopAlarm();
  seconds = 60;
  focusDuration = 60;
  storage.set("focus-duration-seconds", 60);
  syncFocusControls();
  drawTimer();

  const startButton = $("focus-start");
  const caption = $("focus-caption");

  if (startButton) startButton.textContent = "Start focus";
  if (caption) {
    caption.textContent = "Timer reset to 00:01:00. Ready when you are.";
  }
});

syncFocusControls();
drawTimer();
$("profile-settings-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();

  const status = $("profile-settings-status");
  const firebaseUser = auth.currentUser;

  const setStatus = (message) => {
    if (status) status.textContent = message;
  };

  if (!firebaseUser) {
    setStatus("Please sign in again before changing your account settings.");
    return;
  }

  const name = $("settings-username").value.trim();
  const email = $("settings-email").value.trim().toLowerCase();
  const currentPassword = $("settings-current-password")?.value || "";
  const password = $("settings-password").value;
  const confirmPassword = $("settings-password-confirm").value;

  const oldEmail = (firebaseUser.email || "").toLowerCase();
  const emailChanged = email !== oldEmail;
  const passwordChanged = password.length > 0;

  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    setStatus("Enter a username and valid email address.");
    return;
  }

  if (passwordChanged && password.length < 8) {
    setStatus("The new password must be at least 8 characters.");
    return;
  }

  if (password !== confirmPassword) {
    setStatus("The new passwords do not match.");
    return;
  }

  if (emailChanged && passwordChanged) {
    setStatus("Please save your email change first, then change your password separately.");
    return;
  }

  const providers = firebaseUser.providerData.map((provider) => provider.providerId);
  const hasPasswordLogin = providers.includes("password");
  const hasGoogleLogin = providers.includes("google.com");

  if (passwordChanged && !hasPasswordLogin) {
    setStatus(
      hasGoogleLogin
        ? "Your account uses Google sign-in. Its password is managed by Google."
        : "This account does not support changing its password here."
    );
    return;
  }

  if (emailChanged && !hasPasswordLogin) {
    setStatus(
      hasGoogleLogin
        ? "Your email is managed by Google. Change it through your Google account."
        : "This account's email must be changed through its sign-in provider."
    );
    return;
  }

  if ((emailChanged || passwordChanged) && !currentPassword) {
    setStatus("Enter your current password to make this account change.");
    return;
  }

  const submitButton = e.submitter;
  if (submitButton) submitButton.disabled = true;

  try {
    setStatus("Saving your account settings…");

    // Sensitive email/password changes require recent authentication.
    if (emailChanged || passwordChanged) {
      const credential = EmailAuthProvider.credential(firebaseUser.email, currentPassword);

      await reauthenticateWithCredential(firebaseUser, credential);
    }

    if (emailChanged) {
      await updateEmail(firebaseUser, email);
    }

    if (passwordChanged) {
      await updatePassword(firebaseUser, password);
    }

    if (firebaseUser.displayName !== name) {
      await updateProfile(firebaseUser, {
        displayName: name
      });
    }

    const updatedEmail = (firebaseUser.email || email).toLowerCase();

    // Update the signed-in user's Firestore profile.
    // Save the signed-in user's profile and preferences to Firestore.
    const pictureToSave = pendingProfilePicture !== undefined ? pendingProfilePicture : readProfilePicture();

    await setDoc(
      doc(db, "users", firebaseUser.uid),
      {
        uid: firebaseUser.uid,
        name,
        email: updatedEmail,
        profilePicture: pictureToSave || "",
        theme: localStorage.getItem(NORTH_THEME_KEY) || "dark",
        updatedAt: serverTimestamp()
      },
      { merge: true }
    );

    // Keep North's browser session consistent with Firebase.
    const oldPrefix = getUserPrefix();
    const oldPictureKey = getPicKey();
    const savedPicture = localStorage.getItem(oldPictureKey);

    user = {
      ...user,
      uid: firebaseUser.uid,
      name,
      email: updatedEmail
    };

    // Keep the local cache under the updated email prefix.
    const newPrefix = getUserPrefix();

    if (oldPrefix !== newPrefix) {
      const cachedEntries = [];

      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);

        if (key && key.startsWith(oldPrefix)) {
          cachedEntries.push([newPrefix + key.slice(oldPrefix.length), localStorage.getItem(key)]);
        }
      }

      cachedEntries.forEach(([key, value]) => {
        if (value !== null) localStorage.setItem(key, value);
      });
    }

    if (savedPicture) {
      localStorage.setItem(getPicKey(), savedPicture);
    }

    if (pendingProfilePicture !== undefined) {
      if (pendingProfilePicture) localStorage.setItem(getPicKey(), pendingProfilePicture);
      else localStorage.removeItem(getPicKey());
      pendingProfilePicture = undefined;
    }
    sessionStorage.setItem("north-user", JSON.stringify(user));
    localStorage.setItem("north-profile-name", name);
    localStorage.setItem("north-profile-email", updatedEmail);
    localStorage.setItem("north-profile-updated", String(Date.now()));

    if (localStorage.getItem("north-remember-user")) {
      localStorage.setItem("north-remember-user", JSON.stringify(user));
    }

    paintNorthUser();
    setupProfilePicture();

    if ($("settings-password")) $("settings-password").value = "";
    if ($("settings-password-confirm")) {
      $("settings-password-confirm").value = "";
    }
    if ($("settings-current-password")) {
      $("settings-current-password").value = "";
    }

    setStatus("Account settings saved successfully.");
  } catch (error) {
    console.error("North account settings error:", error);

    const messages = {
      "auth/wrong-password": "Your current password is incorrect.",
      "auth/invalid-credential": "Your current password is incorrect.",
      "auth/email-already-in-use": "That email address is already in use.",
      "auth/invalid-email": "Enter a valid email address.",
      "auth/weak-password": "Choose a stronger password.",
      "auth/requires-recent-login": "Please sign in again and retry the change.",
      "auth/network-request-failed": "Network error. Check your connection and try again.",
      "permission-denied": "Firebase denied this update. Check your Firestore rules."
    };

    setStatus(messages[error.code] || error.message || "Could not save account settings. Please try again.");
  } finally {
    if (submitButton) submitButton.disabled = false;
  }
});
// Google Calendar token management
let northTokenClient = null;
let northCalendarToken = null;

const NORTH_SHARED_TOKEN_KEY = "north-google-calendar-shared-token";

function saveSharedCalendarToken(accessToken, expiresIn) {
  try {
    localStorage.setItem(
      NORTH_SHARED_TOKEN_KEY,
      JSON.stringify({
        access_token: accessToken,
        expires_at: Date.now() + (Number(expiresIn) || 3600) * 1000 - 60000
      })
    );
  } catch (error) {
    console.warn("Could not save the Google Calendar connection:", error);
  }
}

function restoreSharedCalendarToken() {
  try {
    const saved = JSON.parse(localStorage.getItem(NORTH_SHARED_TOKEN_KEY) || "null");

    if (saved?.access_token && saved.expires_at > Date.now()) {
      northCalendarToken = saved.access_token;

      if (window.gapi?.client) {
        gapi.client.setToken({
          access_token: northCalendarToken
        });
      }

      const visibility = [
        ["google-connect", true],
        ["google-disconnect", false],
        ["calendar-page-connect", true],
        ["calendar-page-disconnect", false]
      ];

      visibility.forEach(([id, hidden]) => {
        const element = $(id);
        if (element) element.hidden = hidden;
      });

      return true;
    }

    localStorage.removeItem(NORTH_SHARED_TOKEN_KEY);
  } catch (error) {
    console.warn("Could not restore the Google Calendar connection:", error);
  }

  return false;
}

function syncDashboardCalendarConnection() {
  if (restoreSharedCalendarToken()) {
    if (northGapiReady) void loadGoogleEvents();
  } else {
    northCalendarToken = null;

    if (window.gapi?.client) {
      gapi.client.setToken("");
    }

    const visibility = [
      ["google-connect", false],
      ["google-disconnect", true],
      ["calendar-page-connect", false],
      ["calendar-page-disconnect", true]
    ];

    visibility.forEach(([id, hidden]) => {
      const element = $(id);
      if (element) element.hidden = hidden;
    });
  }
}
window.addEventListener("storage", (e) => {
  if (e.key === NORTH_SHARED_TOKEN_KEY) {
    syncDashboardCalendarConnection();
    if (!northCalendarToken) renderGoogleEvents([]);
  }
});
const NORTH_CALENDAR_DISCOVERY = "https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest";
const NORTH_CALENDAR_SCOPE = "https://www.googleapis.com/auth/calendar.events";
function calendarConfigReady() {
  const c = window.NORTH_CONFIG || {};
  return !!(
    c.googleCalendarClientId &&
    !c.googleCalendarClientId.includes("PASTE_") &&
    c.googleCalendarApiKey &&
    !c.googleCalendarApiKey.includes("PASTE_")
  );
}
function setCalendarStatus(message) {
  const el = $("calendar-status");
  if (el) el.textContent = message;
  const page = $("calendar-page-status");
  if (page) page.textContent = message;
}
let northGapiReady = false;
let northGisReady = false;
window.northGapiLoaded = function () {
  if (!window.gapi) return;
  gapi.load("client", async () => {
    try {
      const key = window.NORTH_CONFIG?.googleCalendarApiKey || "";
      if (!key || key.includes("PASTE_")) return;
      await gapi.client.init({ apiKey: key, discoveryDocs: [NORTH_CALENDAR_DISCOVERY] });
      northGapiReady = true;
      if (restoreSharedCalendarToken()) {
        setCalendarStatus("Google Calendar connection restored.");
        await loadGoogleEvents();
      } else setCalendarStatus("Ready to connect your Google Calendar.");
    } catch (e) {
      console.warn("Calendar client init:", e);
      setCalendarStatus("Calendar setup needs attention. Check API key and enable Calendar API.");
    }
  });
};

window.northGisLoaded = function () {
  if (!window.google?.accounts?.oauth2) return;
  northGisReady = true;
  const c = window.NORTH_CONFIG || {};
  if (calendarConfigReady()) {
    northTokenClient = google.accounts.oauth2.initTokenClient({
      client_id: c.googleCalendarClientId,
      scope: NORTH_CALENDAR_SCOPE,
      callback: async (response) => {
        if (response.error) {
          setCalendarStatus("Google authorization was not completed.");
          return;
        }
        northCalendarToken = response.access_token;
        saveSharedCalendarToken(northCalendarToken, response.expires_in);
        gapi.client.setToken({ access_token: northCalendarToken });
        if ($("google-connect")) $("google-connect").hidden = true;
        if ($("google-disconnect")) $("google-disconnect").hidden = false;
        if ($("calendar-page-connect")) $("calendar-page-connect").hidden = true;
        if ($("calendar-page-disconnect")) $("calendar-page-disconnect").hidden = false;
        setCalendarStatus("Connected. Loading upcoming events…");
        await loadGoogleEvents();
      }
    });
    setCalendarStatus("Ready to connect your Google Calendar.");
  }
};
// Initialize Google APIs if their scripts loaded before this module.
if (
  window.__northGapiScriptLoaded &&
  typeof window.northGapiLoaded === "function" &&
  !window.__northGapiLoadedCallbackRan
) {
  window.__northGapiLoadedCallbackRan = true;
  window.northGapiLoaded();
}

if (
  window.__northGisScriptLoaded &&
  typeof window.northGisLoaded === "function" &&
  !window.__northGisLoadedCallbackRan
) {
  window.__northGisLoadedCallbackRan = true;
  window.northGisLoaded();
}
let miniCalendarMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
let miniCalendarEvents = [];
function renderMiniCalendar() {
  const title = $("mini-calendar-title"),
    daysHost = $("mini-calendar-days");
  if (!title || !daysHost) return;
  title.textContent = miniCalendarMonth.toLocaleDateString([], { month: "long", year: "numeric" });
  daysHost.innerHTML = "";
  const year = miniCalendarMonth.getFullYear(),
    month = miniCalendarMonth.getMonth(),
    firstDay = new Date(year, month, 1),
    startOffset = firstDay.getDay(),
    daysInMonth = new Date(year, month + 1, 0).getDate(),
    prevDays = new Date(year, month, 0).getDate();
  const eventDates = new Set(
    miniCalendarEvents.map((ev) => {
      const raw = ev.start?.dateTime || ev.start?.date;
      if (!raw) return "";
      const d = new Date(raw);
      return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    })
  );
  const today = new Date();
  for (let i = 0; i < 42; i++) {
    let dayNum,
      dayMonth = month,
      dayYear = year,
      outside = false;
    if (i < startOffset) {
      dayNum = prevDays - startOffset + i + 1;
      dayMonth = month - 1;
      outside = true;
    } else if (i >= startOffset + daysInMonth) {
      dayNum = i - (startOffset + daysInMonth) + 1;
      dayMonth = month + 1;
      outside = true;
    } else dayNum = i - startOffset + 1;
    const date = new Date(year, dayMonth, dayNum),
      key = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`,
      cell = document.createElement("div");
    cell.className = "mini-calendar-day";
    cell.textContent = dayNum;
    if (outside) cell.classList.add("is-outside");
    if (date.toDateString() === today.toDateString()) cell.classList.add("is-today");
    if (eventDates.has(key)) cell.classList.add("has-event");
    cell.title = date.toLocaleDateString();
    daysHost.append(cell);
  }
  const status = $("mini-calendar-status");
  if (status)
    status.textContent = miniCalendarEvents.length
      ? `${miniCalendarEvents.length} upcoming event(s) loaded · dots mark event dates.`
      : "No upcoming events loaded for this calendar preview.";
}
$("mini-calendar-prev")?.addEventListener("click", () => {
  miniCalendarMonth = new Date(miniCalendarMonth.getFullYear(), miniCalendarMonth.getMonth() - 1, 1);
  renderMiniCalendar();
});
$("mini-calendar-next")?.addEventListener("click", () => {
  miniCalendarMonth = new Date(miniCalendarMonth.getFullYear(), miniCalendarMonth.getMonth() + 1, 1);
  renderMiniCalendar();
});
renderMiniCalendar();
function renderGoogleEvents(events) {
  miniCalendarEvents = events || [];
  renderMiniCalendar();
  const host = $("google-events");
  if (!host) return;
  host.innerHTML = "";
  const list = events || [];
  const todayKey = new Date().toLocaleDateString("en-CA");
  const todayCount = list.filter((event) => {
    const raw = event.start?.dateTime || event.start?.date;
    if (!raw) return false;
    return String(raw).slice(0, 10) === todayKey;
  }).length;
  const head = document.createElement("div");
  head.className = "activity-summary-head";
  const intro = document.createElement("div");
  const title = document.createElement("h3");
  title.textContent = "Calendar activity";
  const subtitle = document.createElement("p");
  subtitle.className = "muted";
  subtitle.textContent = list.length
    ? todayCount
      ? `${todayCount} event${todayCount === 1 ? "" : "s"} today · ${list.length} upcoming total`
      : `${list.length} upcoming event${list.length === 1 ? "" : "s"}`
    : "No upcoming Google Calendar events.";
  intro.append(title, subtitle);
  const count = document.createElement("span");
  count.className = "activity-count";
  count.textContent = String(list.length);
  count.setAttribute("aria-label", `${list.length} upcoming events`);
  head.append(intro, count);
  host.append(head);
  if (!list.length) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "Your upcoming Google Calendar activities will appear here when available.";
    host.append(empty);
    return;
  }
  const eventList = document.createElement("div");
  eventList.className = "google-event-list";
  host.append(eventList);
  events.forEach((event) => {
    const row = document.createElement("div");
    row.className = "google-event";
    const start = event.start?.dateTime || event.start?.date;
    const dateObj = event.start?.dateTime ? new Date(start) : new Date(`${start}T12:00:00`);
    const dateLabel = dateObj.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" });
    const timeLabel = event.start?.dateTime
      ? dateObj.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })
      : "All day";
    const when = document.createElement("div");
    when.className = "google-event-when";
    const date = document.createElement("strong");
    date.textContent = dateLabel;
    const time = document.createElement("small");
    time.textContent = timeLabel;
    when.append(date, time);
    const body = document.createElement("div");
    body.className = "google-event-body";
    const title = document.createElement("strong");
    title.textContent = event.summary || "(Untitled event)";
    body.append(title);
    row.append(when, body);
    eventList.append(row);
  });
}
function renderCalendarActivityMessage(message, isError = false) {
  const host = $("google-events");
  if (!host) return;
  host.innerHTML = "";
  const head = document.createElement("div");
  head.className = "activity-summary-head";
  const intro = document.createElement("div");
  const title = document.createElement("h3");
  title.textContent = "Calendar activity";
  const subtitle = document.createElement("p");
  subtitle.className = "muted";
  subtitle.textContent = message;
  intro.append(title, subtitle);
  const count = document.createElement("span");
  count.className = "activity-count";
  count.textContent = "—";
  head.append(intro, count);
  host.append(head);
  if (isError) {
    const detail = document.createElement("p");
    detail.className = "empty-state calendar-error";
    detail.textContent = message;
    host.append(detail);
  }
  const page = $("calendar-page-events");
  if (page) page.innerHTML = host.innerHTML;
}
async function loadGoogleEvents() {
  if (!northCalendarToken) {
    renderCalendarActivityMessage("Connect Google Calendar to see your upcoming activities.");
    return;
  }
  if (!northGapiReady || !window.gapi?.client?.calendar?.events) {
    renderCalendarActivityMessage(
      "Google Calendar is initializing. Please wait a moment and refresh if this persists."
    );
    return;
  }
  try {
    gapi.client.setToken({ access_token: northCalendarToken });
    const cfg = window.NORTH_CONFIG || {};
    const response = await gapi.client.calendar.events.list({
      calendarId: cfg.googleCalendarId || "primary",
      timeMin: new Date().toISOString(),
      showDeleted: false,
      singleEvents: true,
      maxResults: Math.min(20, Math.max(1, Number(cfg.googleCalendarMaxEvents) || 8)),
      orderBy: "startTime"
    });
    renderGoogleEvents(response.result.items || []);
    const page = $("calendar-page-events");
    if (page) page.innerHTML = $("google-events").innerHTML;
  } catch (e) {
    console.warn(e);
    renderCalendarActivityMessage("Could not load Google Calendar events.", true);
  }
}
// NORTH CLOUD SYNC — per-user Firestore document
const NORTH_CLOUD_FIELDS = ["tasks", "schedule", "notes", "focusDurationSeconds"];

let northCloudReady = false;
let northCloudUserId = null;
let northCloudUnsubscribe = null;

function getNorthCloudData() {
  return {
    tasks,
    schedule,
    notes: $("notes-input") ? $("notes-input").value : storage.get("notes", ""),
    focusDurationSeconds: focusDuration
  };
}

async function saveNorthCloudData() {
  const savingUserId = northCloudUserId;

  if (!northCloudReady || !savingUserId || auth.currentUser?.uid !== savingUserId) {
    return;
  }

  try {
    const dashboardData = getNorthCloudData();
    delete dashboardData.notes;

    await setDoc(
      doc(db, "users", savingUserId),
      {
        ...dashboardData,
        updatedAt: serverTimestamp()
      },
      { merge: true }
    );
  } catch (error) {
    console.error("North cloud save failed:", error);

    if ($("notes-status") && !notesDirty) {
      $("notes-status").textContent = "Cloud sync failed. Your local data is still saved.";
    }
  }
}

async function saveNorthNotesToCloud(value) {
  const savingUserId = northCloudUserId;

  if (!northCloudReady || !savingUserId || auth.currentUser?.uid !== savingUserId) {
    if ($("notes-status")) {
      $("notes-status").textContent = "Notes saved on this device; waiting for North to connect.";
    }
    return false;
  }

  try {
    await setDoc(
      doc(db, "users", savingUserId),
      {
        notes: value,
        updatedAt: serverTimestamp()
      },
      { merge: true }
    );

    if (auth.currentUser?.uid === savingUserId && northCloudUserId === savingUserId && notesInput?.value === value) {
      notesDirty = false;

      if ($("notes-status")) {
        $("notes-status").textContent = "Synced with your North account";
      }
    }

    return true;
  } catch (error) {
    console.error("North Notes cloud save failed:", error);

    if ($("notes-status")) {
      $("notes-status").textContent = "Cloud sync failed. Your notes remain saved on this device.";
    }

    return false;
  }
}

function applyNorthCloudData(data) {
  tasks = Array.isArray(data.tasks) ? data.tasks : [];
  schedule = Array.isArray(data.schedule) ? data.schedule : [];

  const notes = typeof data.notes === "string" ? data.notes : "";

  if ($("notes-input") && !notesDirty) {
    $("notes-input").value = notes;
    storage.set("notes", notes);
  }

  const duration = Number(data.focusDurationSeconds);
  const validDuration = Number.isFinite(duration) && duration >= 1 && duration <= 14399;

  const nextDuration = validDuration ? Math.floor(duration) : focusDuration;

  const durationChanged = nextDuration !== focusDuration;

  if (validDuration) {
    focusDuration = nextDuration;
  }

  if (durationChanged) {
    stopTimer();
    seconds = focusDuration;
  }

  // Update this device's cache without deleting existing data.
  storage.set("tasks", tasks);
  storage.set("schedule", schedule);
  if (!notesDirty) {
    storage.set("notes", notes);
  }
  storage.set("focus-duration-seconds", focusDuration);
  storage.set("focus-duration-minutes", Math.ceil(focusDuration / 60));

  renderTasks();
  renderSchedule();
  syncFocusControls();
  drawTimer();

  if ($("notes-status")) {
    $("notes-status").textContent = "Synced with your North account";
  }
}
// Restore profile picture and theme from the signed-in user's cloud profile.
function applyCloudProfilePreferences(data, firebaseUser) {
  if (!firebaseUser || auth.currentUser?.uid !== firebaseUser.uid) return;

  // Keep the North profile associated with the active Firebase account.
  user = {
    ...(user || {}),
    uid: firebaseUser.uid,
    email: firebaseUser.email || user?.email || "",
    name: data.name || firebaseUser.displayName || user?.name || "North"
  };

  // Restore the saved theme when the account has one.
  if (data.theme === "light" || data.theme === "dark") {
    localStorage.setItem(NORTH_THEME_KEY, data.theme);
    applyNorthTheme(data.theme);
  }

  // Restore the picture only if the cloud document contains this field.
  if (Object.prototype.hasOwnProperty.call(data, "profilePicture")) {
    const pictureKey = getPicKey();

    if (typeof data.profilePicture === "string" && data.profilePicture) {
      localStorage.setItem(pictureKey, data.profilePicture);
    } else {
      localStorage.removeItem(pictureKey);
    }
  }

  try {
    sessionStorage.setItem("north-user", JSON.stringify(user));

    if (localStorage.getItem("north-remember-user")) {
      localStorage.setItem("north-remember-user", JSON.stringify(user));
    }
  } catch (error) {
    console.warn("Could not update the local North profile cache:", error);
  }

  paintNorthUser();
  setupProfilePicture();
}
async function initializeNorthCloudSync(firebaseUser) {
  northCloudReady = false;
  northCloudUserId = firebaseUser.uid;

  const userRef = doc(db, "users", firebaseUser.uid);
  const localData = getNorthCloudData();

  try {
    const snapshot = await getDoc(userRef);
    let cloudData = {};

    if (snapshot.exists()) {
      cloudData = snapshot.data();
    } else {
      cloudData = {
        uid: firebaseUser.uid,
        email: firebaseUser.email || "",
        name: firebaseUser.displayName || "North User",
        authProvider: "existing",
        createdAt: serverTimestamp()
      };
    }

    // Preserve local data for fields not yet stored in the cloud.
    const missingFields = {};

    for (const field of NORTH_CLOUD_FIELDS) {
      if (!(field in cloudData)) {
        missingFields[field] = localData[field];
      }
    }

    if (!snapshot.exists() || Object.keys(missingFields).length > 0) {
      await setDoc(
        userRef,
        {
          ...cloudData,
          ...missingFields,
          updatedAt: serverTimestamp()
        },
        { merge: true }
      );
    }

    const initialData = {
      ...cloudData,
      ...missingFields
    };

    applyNorthCloudData(initialData);
    applyCloudProfilePreferences(initialData, firebaseUser);

    // Enable cloud saves only after initialization finishes.
    northCloudReady = true;
    // Retry saving Notes edited before cloud initialization finished.
    if (notesDirty && notesInput) {
      clearTimeout(noteTimer);

      const pendingNotes = notesInput.value;
      storage.set("notes", pendingNotes);

      void saveNorthNotesToCloud(pendingNotes);
    }

    if (northCloudUnsubscribe) {
      northCloudUnsubscribe();
    }

    northCloudUnsubscribe = onSnapshot(
      userRef,
      (updatedSnapshot) => {
        if (!northCloudReady || northCloudUserId !== firebaseUser.uid || !updatedSnapshot.exists()) {
          return;
        }

        const updatedData = updatedSnapshot.data();

        applyNorthCloudData({
          ...getNorthCloudData(),
          ...updatedData
        });

        applyCloudProfilePreferences(updatedData, firebaseUser);
      },
      (error) => {
        console.error("North cloud sync listener:", error);
        if ($("notes-status")) {
          $("notes-status").textContent = "Cloud sync connection lost";
        }
      }
    );

    console.log("North cloud data loaded for:", firebaseUser.uid);
  } catch (error) {
    northCloudReady = false;
    console.error("North cloud initialization failed:", error);

    if ($("notes-status")) {
      $("notes-status").textContent = "Cloud sync unavailable. Your local data is unchanged.";
    }
  }
}
async function logUserLogin(user) {
  const sessionKey = `logged_session_${user.uid}`;
  if (!sessionStorage.getItem(sessionKey)) {
    try {
      await addDoc(collection(db, "user_logins"), {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || user.email.split("@")[0],
        loginTime: serverTimestamp(),
        userAgent: navigator.userAgent
      });
      sessionStorage.setItem(sessionKey, "true");
      console.log("Logged user login to Firestore user_logins");
    } catch (error) {
      console.error("Failed to write to user_logins:", error);
    }
  }
}
onAuthStateChanged(auth, (firebaseUser) => {
  northCloudReady = false;
  northCloudUserId = null;

  if (northCloudUnsubscribe) {
    northCloudUnsubscribe();
    northCloudUnsubscribe = null;
  }

  if (firebaseUser) {
    initializeNorthCloudSync(firebaseUser);
    recordLogin(firebaseUser);
  }
});

const logoutButton = $("logoutButton");

if (logoutButton) {
  logoutButton.addEventListener("click", async (event) => {
    event.preventDefault();

    try {
      const uidBeforeSignOut = auth.currentUser?.uid;

      await signOut(auth);

      if (uidBeforeSignOut) {
        sessionStorage.removeItem(`logged_session_${uidBeforeSignOut}`);
      }

      sessionStorage.removeItem("north-user");
      localStorage.removeItem("north-remember-user");

      window.location.href = "login.html";
    } catch (error) {
      console.error("North sign-out failed:", error);
      alert("Unable to sign out. Please try again.");
    }
  });
}
// DASHBOARD CONTROLS — tasks, navigation, sidebar, and theme dropdown

// ADD TASKS — supports both button clicks and Enter
function addNorthTask() {
  const input = $("task-input");
  const text = input?.value.trim();

  if (!text) {
    input?.focus();
    return;
  }

  tasks.push({
    text,
    done: false
  });

  input.value = "";
  saveTasks();
}

const taskForm = $("task-form");
const taskAddButton = taskForm?.querySelector('button[type="submit"]');

taskForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  addNorthTask();
});

taskAddButton?.addEventListener("click", (event) => {
  event.preventDefault();
  addNorthTask();
});

renderTasks();

// Mobile sidebar toggle
$("menuToggle")?.addEventListener("click", () => {
  $("sidebar")?.classList.toggle("open");
});

// Theme dropdown in Settings
const themeSelect = $("north-theme-select");

if (themeSelect) {
  themeSelect.value = localStorage.getItem(NORTH_THEME_KEY) || "dark";

  themeSelect.addEventListener("change", async () => {
    const value = themeSelect.value === "light" ? "light" : "dark";

    if (typeof window.northSaveThemePreference === "function") {
      await window.northSaveThemePreference(value);
    } else {
      localStorage.setItem(NORTH_THEME_KEY, value);
      applyNorthTheme(value);
    }
  });
}

// Dashboard navigation
function showNorthView(target) {
  const settings = target === "settings";
  const grid = document.querySelector(".widget-grid");
  const heading = document.querySelector(".dashboard > .section-heading");
  const settingsPanel = $("settings-panel");

  if (grid) grid.hidden = settings;
  if (heading) heading.hidden = settings;
  if (settingsPanel) settingsPanel.hidden = !settings;

  const status = $("status-message");

  if (status) {
    status.textContent =
      target === "settings"
        ? "Manage your North account settings."
        : target === "statistics"
          ? `You have completed ${tasks.filter((t) => t.done).length} of ${tasks.length} tasks.`
          : "";
  }
}

document.querySelectorAll(".nav-item").forEach((link) => {
  link.addEventListener("click", (e) => {
    if (!link.dataset.view) return;

    e.preventDefault();

    const target = link.dataset.view;

    document.querySelectorAll(".nav-item").forEach((item) => {
      item.classList.remove("active");
    });

    link.classList.add("active");
    $("sidebar")?.classList.remove("open");

    showNorthView(target);

    if (target === "dashboard") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else if (target !== "settings") {
      $(target)?.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    }

    location.hash = target;
  });
});
// GOOGLE CALENDAR — connect, disconnect, and refresh

$("calendar-page-connect")?.addEventListener("click", () => {
  $("google-connect")?.click();
});

$("calendar-page-disconnect")?.addEventListener("click", () => {
  $("google-disconnect")?.click();
});

$("google-connect")?.addEventListener("click", () => {
  if (!calendarConfigReady()) {
    setCalendarStatus("Add your Google Calendar Client ID and API key in js/config.js first.");
    return;
  }

  if (!northGapiReady || !northGisReady || !northTokenClient) {
    setCalendarStatus("Google services are still loading. Try again in a moment.");
    return;
  }

  northTokenClient.requestAccessToken({
    prompt: northCalendarToken ? "" : "consent"
  });
});

$("google-disconnect")?.addEventListener("click", async () => {
  const confirmed =
    typeof window.northConfirm === "function"
      ? await window.northConfirm("North will stop syncing this Google Calendar until you connect again.", {
          title: "Disconnect Google Calendar?",
          confirmText: "Disconnect",
          danger: true
        })
      : window.confirm("Disconnect Google Calendar?");

  if (!confirmed) return;

  if (northCalendarToken && window.google?.accounts?.oauth2) {
    google.accounts.oauth2.revoke(northCalendarToken, () => {});
  }

  northCalendarToken = null;
  localStorage.removeItem(NORTH_SHARED_TOKEN_KEY);

  if (window.gapi?.client) {
    gapi.client.setToken("");
  }

  const visibility = [
    ["google-connect", false],
    ["google-disconnect", true],
    ["calendar-page-connect", false],
    ["calendar-page-disconnect", true]
  ];

  visibility.forEach(([id, hidden]) => {
    const element = $(id);
    if (element) element.hidden = hidden;
  });

  renderGoogleEvents([]);

  const page = $("calendar-page-events");
  const host = $("google-events");

  if (page && host) page.innerHTML = host.innerHTML;

  setCalendarStatus("Disconnected from Google Calendar.");
});

setInterval(
  () => {
    if (northCalendarToken) {
      void loadGoogleEvents();
    }
  },
  5 * 60 * 1000
);

if (!calendarConfigReady()) {
  setCalendarStatus("Set Google Calendar credentials in js/config.js to connect.");

  renderCalendarActivityMessage("Add your Google Calendar Client ID and API key in js/config.js to load activities.");
} else if (!restoreSharedCalendarToken()) {
  renderCalendarActivityMessage("Connect Google Calendar to see your upcoming activities.");
}
