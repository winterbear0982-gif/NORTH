import { auth, db, onAuthStateChanged } from "./firebase.js";
import { doc, onSnapshot } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

// Shared profile listener for North's Tasks, Focus, and Statistics pages.
export function watchNorthProfile(callback) {
  let stopDoc = null;
  const stopAuth = onAuthStateChanged(auth, user => {
    if (stopDoc) { stopDoc(); stopDoc = null; }
    if (!user) { callback(null); return; }
    stopDoc = onSnapshot(doc(db, "users", user.uid), snap => {
      const data = snap.exists() ? snap.data() : {};
      const profile = data.profile || data.account || {};
      callback({
        uid: user.uid,
        name: profile.username || profile.name || data.username || data.profileName || data.name || user.displayName || "North",
        email: user.email || profile.email || data.email || "",
        photoURL: profile.photoURL || profile.photoUrl || data.photoURL || data.photoUrl || user.photoURL || ""
      });
    }, error => { console.error("North profile Firestore listener:", error); callback(null, error); });
  });
  return () => { if (stopDoc) stopDoc(); stopAuth(); };
}
