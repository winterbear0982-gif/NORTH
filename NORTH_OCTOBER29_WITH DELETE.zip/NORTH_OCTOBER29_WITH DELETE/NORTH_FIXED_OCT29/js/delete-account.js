import {
  auth,
  db,
  collection,
  doc,
  getDocs,
  query,
  where
} from "./firebase.js";

import {
  deleteUser,
  reauthenticateWithCredential,
  reauthenticateWithPopup,
  EmailAuthProvider,
  GoogleAuthProvider
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

import {
  deleteDoc,
  limit,
  writeBatch
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

const $ = (id) => document.getElementById(id);

function setStatus(message) {
  const status = $("delete-account-status");
  if (status) status.textContent = message;
}

// This file is separate from app.js so the delete button can initialize even
// if another unrelated app.js feature has a runtime error.
const deleteButton = $("delete-account-btn");
if (!deleteButton) {
  console.error("North account deletion: button #delete-account-btn not found.");
} else {
  console.info("North account deletion handler loaded.");
  setStatus("Delete account is ready. Verify your identity before continuing.");

  deleteButton.addEventListener("click", async (event) => {
    // Capture-phase handler takes precedence over any older app.js listener.
    event.preventDefault();
    event.stopImmediatePropagation();
    // Immediate visible feedback confirms that this handler received the click.
    setStatus("Delete request received. Checking your account…");

    const currentUser = auth.currentUser;
    const passwordInput = $("delete-account-password");

    if (!currentUser) {
      setStatus("No Firebase user is signed in. Sign in again, then retry.");
      return;
    }

    const providerIds = (currentUser.providerData || []).map((p) => p.providerId);
    const hasPassword = providerIds.includes("password");
    const hasGoogle = providerIds.includes("google.com");

    if (!hasPassword && !hasGoogle) {
      setStatus("This sign-in provider is not supported by this deletion screen.");
      return;
    }

    if (hasPassword && !passwordInput?.value) {
      setStatus("Enter your current password, then click Delete my account again.");
      passwordInput?.focus();
      return;
    }

    if (typeof window.northConfirm !== "function") {
      setStatus("The confirmation dialog did not load. Refresh the page and retry.");
      return;
    }

    let confirmed = false;
    try {
      confirmed = await window.northConfirm(
        "Permanently delete this North account, profile, and login history? This cannot be undone.",
        { title: "Delete North Account", confirmText: "Delete Account", danger: true }
      );
    } catch (error) {
      console.error("North confirmation dialog error:", error);
      setStatus("The confirmation dialog failed. Check the browser console (F12).");
      return;
    }
    if (!confirmed) {
      setStatus("Account deletion cancelled.");
      return;
    }

    deleteButton.disabled = true;
    const uid = currentUser.uid;
    const email = (currentUser.email || "").toLowerCase();
    const normalizedEmail = email.replace(/[^a-zA-Z0-9]/g, "_");
    const userPrefix = email ? `north-${normalizedEmail}-` : null;
    const pictureKey = email ? `north-pic-${normalizedEmail}` : "north-profile-picture";

    try {
      setStatus("Verifying your identity…");

      if (hasPassword) {
        const credential = EmailAuthProvider.credential(currentUser.email, passwordInput.value);
        await reauthenticateWithCredential(currentUser, credential);
      } else {
        await reauthenticateWithPopup(currentUser, new GoogleAuthProvider());
      }
      if (passwordInput) passwordInput.value = "";

      setStatus("Deleting your login history…");
      while (true) {
        const loginQuery = query(
          collection(db, "user_logins"),
          where("uid", "==", uid),
          limit(400)
        );
        const snapshot = await getDocs(loginQuery);
        if (snapshot.empty) break;

        const batch = writeBatch(db);
        snapshot.docs.forEach((record) => batch.delete(record.ref));
        await batch.commit();
      }

      setStatus("Deleting your North profile…");
      await deleteDoc(doc(db, "users", uid));

      setStatus("Deleting your Firebase sign-in account…");
      await deleteUser(currentUser);

      // Clear only this user's known, account-scoped browser data.
      if (userPrefix) {
        const ownedKeys = [];
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && key.startsWith(userPrefix)) ownedKeys.push(key);
        }
        ownedKeys.forEach((key) => localStorage.removeItem(key));
      }
      localStorage.removeItem(pictureKey);

      try {
        const remembered = JSON.parse(localStorage.getItem("north-remember-user") || "null");
        if (!remembered || (remembered.email || "").toLowerCase() === email) {
          localStorage.removeItem("north-remember-user");
        }
      } catch {
        localStorage.removeItem("north-remember-user");
      }

      try {
        const sessionUser = JSON.parse(sessionStorage.getItem("north-user") || "null");
        if (!sessionUser || (sessionUser.email || "").toLowerCase() === email) {
          sessionStorage.removeItem("north-user");
        }
      } catch {
        sessionStorage.removeItem("north-user");
      }
      sessionStorage.removeItem(`logged_session_${uid}`);

      setStatus("Your North account was deleted successfully. Redirecting…");
      window.location.replace("login.html");
    } catch (error) {
      console.error("North account deletion failed:", error);
      const code = error?.code || "unknown";
      const messages = {
        "auth/wrong-password": "The current password is incorrect.",
        "auth/invalid-credential": "The current password is incorrect. Try again.",
        "auth/user-mismatch": "The Google account does not match the signed-in account.",
        "auth/requires-recent-login": "Please sign in again and retry deletion.",
        "auth/popup-closed-by-user": "Google verification was cancelled.",
        "auth/popup-blocked": "Your browser blocked the Google verification popup.",
        "auth/network-request-failed": "Network error. Check your internet connection.",
        "permission-denied": "Firestore denied access. Check the deployed Firestore rules.",
        "firestore/permission-denied": "Firestore denied access. Check the deployed Firestore rules."
      };
      setStatus(`${messages[code] || `Deletion failed (${code}).`} Check the browser console (F12) for details.`);
    } finally {
      deleteButton.disabled = false;
    }
  }, true);
}
