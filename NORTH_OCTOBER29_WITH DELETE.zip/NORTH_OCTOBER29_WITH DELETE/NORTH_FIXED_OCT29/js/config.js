/* North integrations configuration.
   Browser API keys are public: restrict them to your site and the Calendar API.
*/
window.NORTH_CONFIG = {
  googleCalendarClientId: "473755852360-j7doaol7enra8c9b785f1re3ugrn4oj5.apps.googleusercontent.com",
  googleCalendarApiKey: "AIzaSyBHEtk01YjH2gK21QDkxtoV72ubW6rn1LE",
  googleCalendarId: "primary",
  googleCalendarMaxEvents: 8,
  googleCalendarEmbedUrl: ""
};
