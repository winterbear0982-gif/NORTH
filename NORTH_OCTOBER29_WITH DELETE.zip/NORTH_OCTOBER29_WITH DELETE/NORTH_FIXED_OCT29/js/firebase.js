import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  addDoc,
  getDocs,
  query,
  where,
  serverTimestamp,
  doc,
  getDoc,
  setDoc,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAurqriC3HdyeqqQbHuJTI23oQBRwJw5XA",
  authDomain: "north-273b5.firebaseapp.com",
  databaseURL: "https://north-273b5-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "north-273b5",
  storageBucket: "north-273b5.firebasestorage.app",
  messagingSenderId: "19020143475",
  appId: "1:19020143475:web:f7633e83d4cfadcdb90306",
  measurementId: "G-1QLMNZG781"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize and Export Auth & Database Services
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getFirestore(app);

export {
  signInWithPopup,
  onAuthStateChanged,
  collection,
  addDoc,
  getDocs,
  query,
  where,
  serverTimestamp,
  doc,
  getDoc,
  setDoc,
  onSnapshot
};