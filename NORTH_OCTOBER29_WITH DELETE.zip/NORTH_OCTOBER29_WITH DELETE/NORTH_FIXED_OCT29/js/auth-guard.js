
import { auth, onAuthStateChanged } from "./firebase.js";
import { signOut } from
  "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

export async function signOutNorth() {
  await signOut(auth);

  sessionStorage.removeItem("north-user");
  localStorage.removeItem("north-remember-user");

  window.location.replace("login.html");
}


export function requireNorthUser(onSignedIn) {
  return onAuthStateChanged(
    auth,
    (user) => {
      if (!user) {
        window.location.replace("login.html");
        return;
      }

      onSignedIn(user);
    },
    (error) => {
      console.error("Authentication state error:", error);
      window.location.replace("login.html");
    }
  );
}
