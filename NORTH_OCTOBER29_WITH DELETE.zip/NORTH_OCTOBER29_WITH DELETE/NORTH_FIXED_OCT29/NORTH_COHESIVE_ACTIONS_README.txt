NORTH — CONSISTENT SIGN-OUT STYLE

This version removes the “Back to dashboard” sidebar button from Calendar, Tasks, Focus, Statistics, and Settings. All six main app pages use the same full-width Sign out link format as the Focus page, with the same icon, label, border, radius, and spacing. Existing Firebase sign-out handlers are retained, and Calendar prevents the link from navigating before sign-out completes.

No broad layout redesign is included in this update.

Deployment:
  cd /d "C:\Users\Angela Hawkins\Downloads\NORTH_FIXED_OCT29\NORTH_FIXED_OCT29"
  firebase deploy --only hosting

After deployment, hard-refresh with Ctrl+Shift+R. Sign-out behavior should be verified on the live site.
